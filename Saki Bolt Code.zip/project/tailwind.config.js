/** @type {import('tailwindcss').Config} */
export default {
  content: ['./index.html', './src/**/*.{js,ts,jsx,tsx}'],
  theme: {
    extend: {
      colors: {
        ivory: {
          50: '#fdfcfa',
          100: '#faf7f2',
          200: '#f5efe6',
          300: '#efe4d6',
          400: '#e6d5bf',
          500: '#dcc4a3',
        },
        champagne: {
          50: '#fbf8f3',
          100: '#f5ecdc',
          200: '#e9d4b0',
          300: '#d9b97e',
          400: '#c9a25a',
          500: '#b8893f',
          600: '#9c7132',
          700: '#7d5929',
          800: '#5f4420',
          900: '#3f2d15',
        },
        beige: {
          50: '#faf8f5',
          100: '#f3eee6',
          200: '#e8ddd0',
          300: '#dccab6',
          400: '#cbb094',
          500: '#b89875',
        },
        charcoal: {
          800: '#2b2622',
          900: '#1c1916',
        },
      },
      fontFamily: {
        serif: ['"Cormorant Garamond"', 'Georgia', 'serif'],
        sans: ['Jost', 'system-ui', 'sans-serif'],
      },
      boxShadow: {
        soft: '0 4px 24px -8px rgba(120, 90, 40, 0.12)',
        luxe: '0 12px 40px -12px rgba(120, 90, 40, 0.18)',
        'luxe-lg': '0 24px 60px -20px rgba(120, 90, 40, 0.22)',
      },
      borderRadius: {
        xl: '1rem',
        '2xl': '1.5rem',
        '3xl': '2rem',
      },
      keyframes: {
        fadeIn: {
          '0%': { opacity: '0' },
          '100%': { opacity: '1' },
        },
        slideUp: {
          '0%': { opacity: '0', transform: 'translateY(24px)' },
          '100%': { opacity: '1', transform: 'translateY(0)' },
        },
        slideInLeft: {
          '0%': { opacity: '0', transform: 'translateX(-24px)' },
          '100%': { opacity: '1', transform: 'translateX(0)' },
        },
        scaleIn: {
          '0%': { opacity: '0', transform: 'scale(0.96)' },
          '100%': { opacity: '1', transform: 'scale(1)' },
        },
        shimmer: {
          '0%': { backgroundPosition: '-1000px 0' },
          '100%': { backgroundPosition: '1000px 0' },
        },
      },
      animation: {
        fadeIn: 'fadeIn 0.7s ease-out forwards',
        slideUp: 'slideUp 0.7s ease-out forwards',
        slideInLeft: 'slideInLeft 0.7s ease-out forwards',
        scaleIn: 'scaleIn 0.5s ease-out forwards',
      },
    },
  },
  plugins: [],
};
