/*
# Saki Boutique Catalogue Schema

## Overview
Creates the database schema for a luxury boutique catalogue website (Saki - A Fashion Destination).
This is a catalogue-only site: no prices, no cart, no checkout. Admins manage products via /admin (auth required).
Public visitors browse as anon.

## Tables

### main_categories
Top-level collections shown on the site: Sarees, Kurtis, Salwar Sets, Dress Materials, New Arrivals.
- id (uuid, PK)
- name (text, unique) — e.g. "Sarees"
- slug (text, unique) — URL-friendly identifier
- description (text, nullable)
- display_order (int, default 0)
- created_at (timestamptz)

### subcategories
Sub-categories belonging to a main category (e.g. "Cotton Sarees", "Silk Sarees").
- id (uuid, PK)
- main_category_id (uuid, FK -> main_categories)
- name (text)
- slug (text)
- description (text, nullable)
- display_order (int, default 0)
- created_at (timestamptz)
Unique on (main_category_id, slug).

### products
Individual catalogue products. No price field (catalogue only).
- id (uuid, PK)
- name (text, not null)
- product_code (text, not null)
- main_category_id (uuid, FK -> main_categories)
- subcategory_id (uuid, FK -> subcategories, nullable)
- fabric (text, nullable)
- description (text, nullable)
- colours (text[]) — array of colour names, NOT json. e.g. {"Red","Blue"}
- images (text[]) — array of image URLs in product-images bucket. First = cover.
- availability (text) — 'In Stock' | 'Limited Stock' | 'Out of Stock'
- is_new_arrival (boolean, default false)
- sort_order (int, default 0)
- created_at (timestamptz)

## Security
- RLS enabled on all tables.
- Public (anon, authenticated) can SELECT all data (catalogue is public).
- Only authenticated admins can INSERT/UPDATE/DELETE.
- No user_id columns: single-admin catalogue, writes gated by auth status.
*/

CREATE TABLE IF NOT EXISTS main_categories (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  name text NOT NULL UNIQUE,
  slug text NOT NULL UNIQUE,
  description text,
  display_order int NOT NULL DEFAULT 0,
  created_at timestamptz NOT NULL DEFAULT now()
);

ALTER TABLE main_categories ENABLE ROW LEVEL SECURITY;

CREATE TABLE IF NOT EXISTS subcategories (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  main_category_id uuid NOT NULL REFERENCES main_categories(id) ON DELETE CASCADE,
  name text NOT NULL,
  slug text NOT NULL,
  description text,
  display_order int NOT NULL DEFAULT 0,
  created_at timestamptz NOT NULL DEFAULT now(),
  UNIQUE (main_category_id, slug)
);

ALTER TABLE subcategories ENABLE ROW LEVEL SECURITY;

CREATE TABLE IF NOT EXISTS products (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  name text NOT NULL,
  product_code text NOT NULL,
  main_category_id uuid NOT NULL REFERENCES main_categories(id) ON DELETE CASCADE,
  subcategory_id uuid REFERENCES subcategories(id) ON DELETE SET NULL,
  fabric text,
  description text,
  colours text[] NOT NULL DEFAULT '{}',
  images text[] NOT NULL DEFAULT '{}',
  availability text NOT NULL DEFAULT 'In Stock' CHECK (availability IN ('In Stock','Limited Stock','Out of Stock')),
  is_new_arrival boolean NOT NULL DEFAULT false,
  sort_order int NOT NULL DEFAULT 0,
  created_at timestamptz NOT NULL DEFAULT now()
);

ALTER TABLE products ENABLE ROW LEVEL SECURITY;

-- Indexes for common queries
CREATE INDEX IF NOT EXISTS idx_subcategories_main ON subcategories(main_category_id);
CREATE INDEX IF NOT EXISTS idx_products_main ON products(main_category_id);
CREATE INDEX IF NOT EXISTS idx_products_sub ON products(subcategory_id);
CREATE INDEX IF NOT EXISTS idx_products_new_arrival ON products(is_new_arrival) WHERE is_new_arrival = true;
CREATE INDEX IF NOT EXISTS idx_products_sort ON products(sort_order);

-- ===== Policies: public read, admin write =====

-- main_categories
DROP POLICY IF EXISTS "public_read_main_categories" ON main_categories;
CREATE POLICY "public_read_main_categories" ON main_categories
  FOR SELECT TO anon, authenticated USING (true);

DROP POLICY IF EXISTS "admin_insert_main_categories" ON main_categories;
CREATE POLICY "admin_insert_main_categories" ON main_categories
  FOR INSERT TO authenticated WITH CHECK (true);

DROP POLICY IF EXISTS "admin_update_main_categories" ON main_categories;
CREATE POLICY "admin_update_main_categories" ON main_categories
  FOR UPDATE TO authenticated USING (true) WITH CHECK (true);

DROP POLICY IF EXISTS "admin_delete_main_categories" ON main_categories;
CREATE POLICY "admin_delete_main_categories" ON main_categories
  FOR DELETE TO authenticated USING (true);

-- subcategories
DROP POLICY IF EXISTS "public_read_subcategories" ON subcategories;
CREATE POLICY "public_read_subcategories" ON subcategories
  FOR SELECT TO anon, authenticated USING (true);

DROP POLICY IF EXISTS "admin_insert_subcategories" ON subcategories;
CREATE POLICY "admin_insert_subcategories" ON subcategories
  FOR INSERT TO authenticated WITH CHECK (true);

DROP POLICY IF EXISTS "admin_update_subcategories" ON subcategories;
CREATE POLICY "admin_update_subcategories" ON subcategories
  FOR UPDATE TO authenticated USING (true) WITH CHECK (true);

DROP POLICY IF EXISTS "admin_delete_subcategories" ON subcategories;
CREATE POLICY "admin_delete_subcategories" ON subcategories
  FOR DELETE TO authenticated USING (true);

-- products
DROP POLICY IF EXISTS "public_read_products" ON products;
CREATE POLICY "public_read_products" ON products
  FOR SELECT TO anon, authenticated USING (true);

DROP POLICY IF EXISTS "admin_insert_products" ON products;
CREATE POLICY "admin_insert_products" ON products
  FOR INSERT TO authenticated WITH CHECK (true);

DROP POLICY IF EXISTS "admin_update_products" ON products;
CREATE POLICY "admin_update_products" ON products
  FOR UPDATE TO authenticated USING (true) WITH CHECK (true);

DROP POLICY IF EXISTS "admin_delete_products" ON products;
CREATE POLICY "admin_delete_products" ON products
  FOR DELETE TO authenticated USING (true);

-- Storage bucket for product images (idempotent)
INSERT INTO storage.buckets (id, name, public)
VALUES ('product-images', 'product-images', true)
ON CONFLICT (id) DO NOTHING;

-- Storage policies: public read, authenticated write
DROP POLICY IF EXISTS "public_read_product_images" ON storage.objects;
CREATE POLICY "public_read_product_images" ON storage.objects
  FOR SELECT TO anon, authenticated
  USING (bucket_id = 'product-images');

DROP POLICY IF EXISTS "admin_insert_product_images" ON storage.objects;
CREATE POLICY "admin_insert_product_images" ON storage.objects
  FOR INSERT TO authenticated
  WITH CHECK (bucket_id = 'product-images');

DROP POLICY IF EXISTS "admin_update_product_images" ON storage.objects;
CREATE POLICY "admin_update_product_images" ON storage.objects
  FOR UPDATE TO authenticated
  USING (bucket_id = 'product-images') WITH CHECK (bucket_id = 'product-images');

DROP POLICY IF EXISTS "admin_delete_product_images" ON storage.objects;
CREATE POLICY "admin_delete_product_images" ON storage.objects
  FOR DELETE TO authenticated
  USING (bucket_id = 'product-images');
