ALTER TABLE main_categories ADD COLUMN IF NOT EXISTS image text;
ALTER TABLE subcategories ADD COLUMN IF NOT EXISTS image text;