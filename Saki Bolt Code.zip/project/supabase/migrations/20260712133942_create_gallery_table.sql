/*
# Create gallery_images table

## Overview
Adds a table to store gallery images managed via the admin dashboard and displayed on the public gallery page.

## Table
### gallery_images
- id (uuid, PK)
- url (text) — public URL of the image in product-images bucket
- label (text, nullable) — optional caption
- sort_order (int, default 0)
- created_at (timestamptz)

## Security
- RLS enabled.
- Public (anon, authenticated) SELECT.
- Authenticated admin INSERT/UPDATE/DELETE.
*/

CREATE TABLE IF NOT EXISTS gallery_images (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  url text NOT NULL,
  label text,
  sort_order int NOT NULL DEFAULT 0,
  created_at timestamptz NOT NULL DEFAULT now()
);

ALTER TABLE gallery_images ENABLE ROW LEVEL SECURITY;

CREATE INDEX IF NOT EXISTS idx_gallery_sort ON gallery_images(sort_order);

DROP POLICY IF EXISTS "public_read_gallery_images" ON gallery_images;
CREATE POLICY "public_read_gallery_images" ON gallery_images
  FOR SELECT TO anon, authenticated USING (true);

DROP POLICY IF EXISTS "admin_insert_gallery_images" ON gallery_images;
CREATE POLICY "admin_insert_gallery_images" ON gallery_images
  FOR INSERT TO authenticated WITH CHECK (true);

DROP POLICY IF EXISTS "admin_update_gallery_images" ON gallery_images;
CREATE POLICY "admin_update_gallery_images" ON gallery_images
  FOR UPDATE TO authenticated USING (true) WITH CHECK (true);

DROP POLICY IF EXISTS "admin_delete_gallery_images" ON gallery_images;
CREATE POLICY "admin_delete_gallery_images" ON gallery_images
  FOR DELETE TO authenticated USING (true);
