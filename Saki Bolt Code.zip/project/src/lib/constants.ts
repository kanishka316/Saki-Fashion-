export const CONTACT = {
  phone: '+91 9361706046',
  phoneRaw: '919361706046',
  whatsapp: '919361706046',
  instagram: 'https://www.instagram.com/saki_fashion_destination',
  instagramHandle: 'saki_fashion_destination',
  address: {
    line1: '1/305, S K Complex',
    line2: 'Pariyur Amman Nagar, Vaikal Medu',
    line3: 'Nochipalayam Pirivu',
    city: 'Tirupur',
    state: 'Tamil Nadu',
    pincode: '641605',
  },
  mapsQuery: 'Saki Fashion Destination, Tirupur, Tamil Nadu 641605',
  mapsEmbed:
    'https://www.google.com/maps?q=Saki+Fashion+Destination+Tirupur+Tamil+Nadu+641605&output=embed',
  mapsLink:
    'https://www.google.com/maps/search/?api=1&query=Saki+Fashion+Destination+Tirupur+Tamil+Nadu+641605',
};

export const BRAND = {
  name: 'Saki',
  tagline: 'A Fashion Destination',
  full: 'Saki — A Fashion Destination',
};
