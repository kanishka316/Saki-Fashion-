import { createClient } from '@supabase/supabase-js';

const supabaseUrl = import.meta.env.VITE_SUPABASE_URL as string;
const supabaseAnonKey = import.meta.env.VITE_SUPABASE_ANON_KEY as string;

if (!supabaseUrl || !supabaseAnonKey) {
  throw new Error('Missing Supabase environment variables');
}

export const supabase = createClient(supabaseUrl, supabaseAnonKey, {
  auth: {
    persistSession: true,
    autoRefreshToken: true,
    detectSessionInUrl: true,
  },
});

export const PRODUCT_IMAGES_BUCKET = 'product-images';

export type MainCategory = {
  id: string;
  name: string;
  slug: string;
  description: string | null;
  image: string | null;
  display_order: number;
  created_at: string;
};

export type Subcategory = {
  id: string;
  main_category_id: string;
  name: string;
  slug: string;
  description: string | null;
  image: string | null;
  display_order: number;
  created_at: string;
};

export type Product = {
  id: string;
  name: string;
  product_code: string;
  main_category_id: string;
  subcategory_id: string | null;
  fabric: string | null;
  description: string | null;
  colours: string[];
  images: string[];
  availability: 'In Stock' | 'Limited Stock' | 'Out of Stock';
  price: number;
  is_new_arrival: boolean;
  sort_order: number;
  created_at: string;
};

export type ProductWithRelations = Product & {
  main_category?: MainCategory;
  subcategory?: Subcategory | null;
};

export type GalleryImage = {
  id: string;
  url: string;
  label: string | null;
  sort_order: number;
  created_at: string;
};
