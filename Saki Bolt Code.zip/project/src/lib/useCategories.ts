import { useEffect, useState } from 'react';
import { supabase, type MainCategory, type Subcategory } from './supabase';

export function useCategories() {
  const [mainCategories, setMainCategories] = useState<MainCategory[]>([]);
  const [subcategories, setSubcategories] = useState<Subcategory[]>([]);
  const [loading, setLoading] = useState(true);

  useEffect(() => {
    let mounted = true;

    async function load() {
      const [{ data: mc }, { data: sc }] = await Promise.all([
        supabase.from('main_categories').select('*').order('display_order'),
        supabase.from('subcategories').select('*').order('display_order'),
      ]);
      if (!mounted) return;
      setMainCategories(mc ?? []);
      setSubcategories(sc ?? []);
      setLoading(false);
    }

    load();

    const channel = supabase
      .channel('categories-changes')
      .on(
        'postgres_changes',
        { event: '*', schema: 'public', table: 'main_categories' },
        load,
      )
      .on(
        'postgres_changes',
        { event: '*', schema: 'public', table: 'subcategories' },
        load,
      )
      .subscribe();

    return () => {
      mounted = false;
      supabase.removeChannel(channel);
    };
  }, []);

  return { mainCategories, subcategories, loading };
}

export function useSubcategoriesByMain(mainCategoryId: string | null) {
  const [subcategories, setSubcategories] = useState<Subcategory[]>([]);
  const [loading, setLoading] = useState(true);

  useEffect(() => {
    if (!mainCategoryId) {
      setSubcategories([]);
      setLoading(false);
      return;
    }
    let mounted = true;

    async function load() {
      const { data } = await supabase
        .from('subcategories')
        .select('*')
        .eq('main_category_id', mainCategoryId)
        .order('display_order');
      if (mounted) {
        setSubcategories(data ?? []);
        setLoading(false);
      }
    }

    load();
  }, [mainCategoryId]);

  return { subcategories, loading };
}
