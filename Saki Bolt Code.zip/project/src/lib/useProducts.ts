import { useEffect, useState } from 'react';
import { supabase, type Product, type MainCategory, type Subcategory } from './supabase';

export type ProductFilter = {
  mainCategorySlug?: string;
  subcategorySlug?: string;
  newArrivalsOnly?: boolean;
  search?: string;
};

export type ProductWithRelations = Product & {
  main_category?: MainCategory;
  subcategory?: Subcategory | null;
};

export function useProducts(filter: ProductFilter = {}) {
  const [products, setProducts] = useState<ProductWithRelations[]>([]);
  const [loading, setLoading] = useState(true);

  useEffect(() => {
    let mounted = true;

    async function load() {
      let query = supabase
        .from('products')
        .select('*, main_category:main_categories(*), subcategory:subcategories(*)');

      if (filter.newArrivalsOnly) {
        query = query.eq('is_new_arrival', true);
      }

      if (filter.mainCategorySlug && !filter.newArrivalsOnly) {
        const { data: mc } = await supabase
          .from('main_categories')
          .select('id')
          .eq('slug', filter.mainCategorySlug)
          .maybeSingle();
        if (mc) query = query.eq('main_category_id', mc.id);
      }

      if (filter.subcategorySlug) {
        const { data: sc } = await supabase
          .from('subcategories')
          .select('id')
          .eq('slug', filter.subcategorySlug)
          .maybeSingle();
        if (sc) query = query.eq('subcategory_id', sc.id);
      }

      const { data } = await query.order('sort_order').order('created_at', { ascending: false });

      let rows = (data ?? []) as ProductWithRelations[];

      if (filter.search) {
        const q = filter.search.toLowerCase();
        rows = rows.filter(
          (p) =>
            p.name.toLowerCase().includes(q) ||
            p.product_code.toLowerCase().includes(q) ||
            (p.fabric ?? '').toLowerCase().includes(q),
        );
      }

      if (mounted) {
        setProducts(rows);
        setLoading(false);
      }
    }

    load();

    const channel = supabase
      .channel('products-changes')
      .on(
        'postgres_changes',
        { event: '*', schema: 'public', table: 'products' },
        load,
      )
      .subscribe();

    return () => {
      mounted = false;
      supabase.removeChannel(channel);
    };
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [
    filter.mainCategorySlug,
    filter.subcategorySlug,
    filter.newArrivalsOnly,
    filter.search,
  ]);

  return { products, loading };
}

export function useProduct(id: string | undefined) {
  const [product, setProduct] = useState<ProductWithRelations | null>(null);
  const [loading, setLoading] = useState(true);

  useEffect(() => {
    if (!id) {
      setProduct(null);
      setLoading(false);
      return;
    }
    let mounted = true;

    async function load() {
      const { data } = await supabase
        .from('products')
        .select('*, main_category:main_categories(*), subcategory:subcategories(*)')
        .eq('id', id)
        .maybeSingle();
      if (mounted) {
        setProduct(data as ProductWithRelations | null);
        setLoading(false);
      }
    }

    load();

    const channel = supabase
      .channel(`product-${id}`)
      .on(
        'postgres_changes',
        { event: '*', schema: 'public', table: 'products', filter: `id=eq.${id}` },
        load,
      )
      .subscribe();

    return () => {
      mounted = false;
      supabase.removeChannel(channel);
    };
  }, [id]);

  return { product, loading };
}
