import { useEffect, useState } from 'react';
import { supabase, type GalleryImage } from './supabase';

export function useGalleryImages() {
  const [images, setImages] = useState<GalleryImage[]>([]);
  const [loading, setLoading] = useState(true);

  useEffect(() => {
    let mounted = true;

    async function load() {
      const { data } = await supabase
        .from('gallery_images')
        .select('*')
        .order('sort_order')
        .order('created_at', { ascending: false });
      if (mounted) {
        setImages(data ?? []);
        setLoading(false);
      }
    }

    load();

    const channel = supabase
      .channel('gallery-changes')
      .on(
        'postgres_changes',
        { event: '*', schema: 'public', table: 'gallery_images' },
        load,
      )
      .subscribe();

    return () => {
      mounted = false;
      supabase.removeChannel(channel);
    };
  }, []);

  return { images, loading };
}
