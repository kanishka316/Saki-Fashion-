import { useEffect, useState } from 'react';

// Intersection Observer hook for scroll-triggered animations
export function useReveal<T extends HTMLElement = HTMLDivElement>() {
  const [ref, setRef] = useState<T | null>(null);
  const [visible, setVisible] = useState(false);

  useEffect(() => {
    if (!ref) return;
    const observer = new IntersectionObserver(
      ([entry]) => {
        if (entry.isIntersecting) {
          setVisible(true);
          observer.disconnect();
        }
      },
      { threshold: 0.12, rootMargin: '0px 0px -40px 0px' },
    );
    observer.observe(ref);
    return () => observer.disconnect();
  }, [ref]);

  return { ref: setRef, visible };
}

export function revealClass(visible: boolean, base = ''): string {
  return `${base} transition-all duration-700 ease-out ${
    visible ? 'opacity-100 translate-y-0' : 'opacity-0 translate-y-6'
  }`;
}
