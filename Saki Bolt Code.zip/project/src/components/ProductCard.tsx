import { Link } from 'react-router-dom';
import { type ProductWithRelations } from '../lib/useProducts';

const availabilityStyles: Record<string, string> = {
  'In Stock': 'bg-green-100 text-green-700',
  'Limited Stock': 'bg-champagne-200 text-champagne-700',
  'Out of Stock': 'bg-red-100 text-red-600',
};

export default function ProductCard({ product }: { product: ProductWithRelations }) {
  const cover = product.images[0];
  return (
    <Link
      to={`/product/${product.id}`}
      className="card-luxe hover-luxe group block overflow-hidden hover:shadow-luxe"
    >
      <div className="relative aspect-[3/4] overflow-hidden rounded-t-2xl bg-ivory-100">
        {cover ? (
          <img
            src={cover}
            alt={product.name}
            loading="lazy"
            className="h-full w-full object-cover image-zoom"
          />
        ) : (
          <div className="flex h-full w-full items-center justify-center bg-ivory-100 text-beige-400">
            <span className="text-xs uppercase tracking-widest">No Image</span>
          </div>
        )}
        {product.is_new_arrival && (
          <span className="absolute left-3 top-3 rounded-full bg-charcoal-900 px-3 py-1 text-[0.6rem] font-medium uppercase tracking-[0.15em] text-ivory-50">
            New
          </span>
        )}
        <span
          className={`absolute right-3 top-3 rounded-full px-3 py-1 text-[0.6rem] font-medium uppercase tracking-[0.1em] ${
            availabilityStyles[product.availability] ?? availabilityStyles['In Stock']
          }`}
        >
          {product.availability}
        </span>
      </div>
      <div className="p-5">
        <h3 className="font-serif text-lg font-medium text-charcoal-900 transition-colors group-hover:text-champagne-500">
          {product.name}
        </h3>
        <p className="mt-1 text-xs uppercase tracking-[0.12em] text-beige-500">
          {product.product_code}
        </p>
        {product.fabric && (
          <p className="mt-2 text-sm text-charcoal-800/70">{product.fabric}</p>
        )}
        {product.colours.length > 0 && (
          <div className="mt-3 flex flex-wrap gap-1.5">
            {product.colours.slice(0, 5).map((c) => (
              <span
                key={c}
                className="rounded-full border border-ivory-300 bg-ivory-50 px-2.5 py-0.5 text-[0.65rem] text-charcoal-800"
              >
                {c}
              </span>
            ))}
          </div>
        )}
        <span className="mt-4 inline-block text-xs font-medium uppercase tracking-[0.15em] text-champagne-500 transition-colors group-hover:text-champagne-600">
          View Details →
        </span>
      </div>
    </Link>
  );
}
