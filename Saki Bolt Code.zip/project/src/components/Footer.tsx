import { Link } from 'react-router-dom';
import { Phone, Instagram, MapPin, MessageCircle } from 'lucide-react';
import { BRAND, CONTACT } from '../lib/constants';

const quickLinks = [
  { to: '/', label: 'Home' },
  { to: '/collections', label: 'Collections' },
  { to: '/gallery', label: 'Gallery' },
  { to: '/about', label: 'About Us' },
  { to: '/contact', label: 'Contact' },
];

const collectionLinks = [
  { to: '/collections/sarees', label: 'Sarees' },
  { to: '/collections/dress-materials', label: 'Dress Materials' },
  { to: '/collections/new-arrivals', label: 'New Arrivals' },
];

export default function Footer() {
  return (
    <footer className="mt-24 bg-charcoal-900 text-ivory-100">
      <div className="container-luxe grid gap-12 py-16 md:grid-cols-4">
        {/* Brand */}
        <div className="md:col-span-1">
          <h3 className="font-serif text-3xl font-semibold text-ivory-50">{BRAND.name}</h3>
          <p className="mt-1 text-[0.65rem] font-medium uppercase tracking-[0.3em] text-champagne-300">
            {BRAND.tagline}
          </p>
          <p className="mt-4 text-sm leading-relaxed text-ivory-200/80">
            Elegance crafted for every woman. Timeless sarees and premium dress materials.
          </p>
        </div>

        {/* Quick Links */}
        <div>
          <h4 className="text-xs font-medium uppercase tracking-[0.2em] text-champagne-300">
            Quick Links
          </h4>
          <ul className="mt-4 space-y-2.5">
            {quickLinks.map((l) => (
              <li key={l.to}>
                <Link
                  to={l.to}
                  className="text-sm text-ivory-200/80 transition-colors hover:text-champagne-300"
                >
                  {l.label}
                </Link>
              </li>
            ))}
          </ul>
        </div>

        {/* Collections */}
        <div>
          <h4 className="text-xs font-medium uppercase tracking-[0.2em] text-champagne-300">
            Collections
          </h4>
          <ul className="mt-4 space-y-2.5">
            {collectionLinks.map((l) => (
              <li key={l.to}>
                <Link
                  to={l.to}
                  className="text-sm text-ivory-200/80 transition-colors hover:text-champagne-300"
                >
                  {l.label}
                </Link>
              </li>
            ))}
          </ul>
        </div>

        {/* Contact */}
        <div>
          <h4 className="text-xs font-medium uppercase tracking-[0.2em] text-champagne-300">
            Reach Us
          </h4>
          <ul className="mt-4 space-y-3 text-sm text-ivory-200/80">
            <li>
              <a
                href={`tel:${CONTACT.phoneRaw}`}
                className="flex items-center gap-2.5 transition-colors hover:text-champagne-300"
              >
                <Phone size={15} className="text-champagne-300" />
                {CONTACT.phone}
              </a>
            </li>
            <li>
              <a
                href={`https://wa.me/${CONTACT.whatsapp}`}
                target="_blank"
                rel="noreferrer"
                className="flex items-center gap-2.5 transition-colors hover:text-champagne-300"
              >
                <MessageCircle size={15} className="text-champagne-300" />
                WhatsApp
              </a>
            </li>
            <li>
              <a
                href={CONTACT.instagram}
                target="_blank"
                rel="noreferrer"
                className="flex items-center gap-2.5 transition-colors hover:text-champagne-300"
              >
                <Instagram size={15} className="text-champagne-300" />
                {CONTACT.instagramHandle}
              </a>
            </li>
            <li className="flex items-start gap-2.5">
              <MapPin size={15} className="mt-0.5 shrink-0 text-champagne-300" />
              <span>
                {CONTACT.address.line1}, {CONTACT.address.line2}, {CONTACT.address.line3},{' '}
                {CONTACT.address.city}, {CONTACT.address.state} - {CONTACT.address.pincode}
              </span>
            </li>
          </ul>
        </div>
      </div>

      <div className="border-t border-ivory-200/10">
        <div className="container-luxe flex flex-col items-center justify-between gap-3 py-6 sm:flex-row">
          <p className="text-xs text-ivory-200/60">
            © {new Date().getFullYear()} {BRAND.full}. All rights reserved.
          </p>
          <p className="text-xs text-ivory-200/60">Crafted with elegance in Tirupur, Tamil Nadu.</p>
        </div>
      </div>
    </footer>
  );
}
