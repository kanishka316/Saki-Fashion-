import { useEffect, useState } from 'react';
import { Link } from 'react-router-dom';
import { ArrowRight, MapPin } from 'lucide-react';

const slides = [
  {
    img: '/images/saree1.jpg',
    title: 'Elegance Crafted for Every Woman',
    sub: 'Discover timeless sarees and premium dress materials for every occasion.',
  },
  {
    img: '/images/saree2.jpg',
    title: 'Sarees That Tell a Story',
    sub: 'From Kanchipuram silk to Banarasi weaves — heritage reimagined for the modern woman.',
  },
  {
    img: '/images/saree3.jpg',
    title: 'Everyday Grace, Festive Glamour',
    sub: 'Premium dress materials curated for every occasion.',
  },
  {
    img: '/images/saree4.jpg',
    title: 'Woven with Passion, Draped with Love',
    sub: 'Handpicked fabrics that celebrate the rich heritage of Indian craftsmanship.',
  },
];

export default function HeroSlider() {
  const [index, setIndex] = useState(0);

  useEffect(() => {
    const t = setInterval(() => setIndex((i) => (i + 1) % slides.length), 6000);
    return () => clearInterval(t);
  }, []);

  return (
    <section className="relative h-[100svh] min-h-[600px] w-full overflow-hidden">
      {slides.map((slide, i) => (
        <div
          key={i}
          className={`absolute inset-0 transition-opacity duration-1000 ${
            i === index ? 'opacity-100' : 'opacity-0'
          }`}
        >
          <img
            src={slide.img}
            alt={slide.title}
            className="h-full w-full object-cover"
            style={{ transform: i === index ? 'scale(1.05)' : 'scale(1)', transition: 'transform 6s ease-out' }}
          />
          <div className="absolute inset-0 bg-gradient-to-b from-charcoal-900/40 via-charcoal-900/30 to-charcoal-900/60" />
        </div>
      ))}

      <div className="relative z-10 flex h-full items-center justify-center">
        <div className="container-luxe text-center">
          <p className="mb-4 animate-fadeIn text-xs font-medium uppercase tracking-[0.4em] text-champagne-200">
            Saki — A Fashion Destination
          </p>
          <h1 className="max-w-3xl text-balance text-4xl font-medium leading-tight text-ivory-50 drop-shadow-lg sm:text-5xl md:text-6xl lg:text-7xl">
            {slides[index].title}
          </h1>
          <p className="mx-auto mt-5 max-w-xl text-balance text-base leading-relaxed text-ivory-100/90 sm:text-lg">
            {slides[index].sub}
          </p>
          <div className="mt-8 flex flex-col items-center justify-center gap-3 sm:flex-row">
            <Link to="/collections" className="btn-primary">
              Explore Collections
              <ArrowRight size={16} />
            </Link>
            <Link to="/contact" className="btn-outline border-ivory-100/40 text-ivory-50 hover:bg-ivory-50 hover:text-charcoal-900">
              <MapPin size={16} />
              Visit Boutique
            </Link>
          </div>
        </div>
      </div>

      {/* Dots */}
      <div className="absolute bottom-8 left-1/2 z-20 flex -translate-x-1/2 gap-2">
        {slides.map((_, i) => (
          <button
            key={i}
            onClick={() => setIndex(i)}
            className={`h-1.5 rounded-full transition-all duration-300 ${
              i === index ? 'w-8 bg-champagne-300' : 'w-1.5 bg-ivory-50/50'
            }`}
            aria-label={`Slide ${i + 1}`}
          />
        ))}
      </div>
    </section>
  );
}
