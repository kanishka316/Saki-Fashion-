import { useState, type ReactNode } from 'react';
import { Link, NavLink, useNavigate } from 'react-router-dom';
import {
  LayoutDashboard,
  Package,
  Tags,
  Boxes,
  Images,
  LogOut,
  Menu,
  X,
  ExternalLink,
} from 'lucide-react';
import { useAuth } from '../../lib/auth';
import { BRAND } from '../../lib/constants';

const navItems = [
  { to: '/admin', label: 'Dashboard', icon: LayoutDashboard, end: true },
  { to: '/admin/products', label: 'Products', icon: Package, end: false },
  { to: '/admin/categories', label: 'Categories', icon: Tags, end: false },
  { to: '/admin/stock', label: 'Stock', icon: Boxes, end: false },
  { to: '/admin/gallery', label: 'Gallery', icon: Images, end: false },
];

export default function AdminLayout({ children, title }: { children: ReactNode; title: string }) {
  const { signOut } = useAuth();
  const navigate = useNavigate();
  const [sidebarOpen, setSidebarOpen] = useState(false);

  const handleSignOut = async () => {
    await signOut();
    navigate('/admin/login', { replace: true });
  };

  return (
    <div className="min-h-screen bg-ivory-50">
      {/* Mobile header */}
      <header className="sticky top-0 z-30 flex items-center justify-between border-b border-ivory-200 bg-ivory-50 px-4 py-3 lg:hidden">
        <div className="flex items-center gap-2">
          <button
            onClick={() => setSidebarOpen(true)}
            className="rounded-lg p-2 text-charcoal-900 hover:bg-ivory-100"
          >
            <Menu size={20} />
          </button>
          <span className="font-serif text-xl font-semibold text-charcoal-900">{BRAND.name}</span>
          <span className="text-[0.6rem] font-medium uppercase tracking-[0.2em] text-champagne-500">
            Admin
          </span>
        </div>
      </header>

      {/* Sidebar */}
      <aside
        className={`fixed inset-y-0 left-0 z-40 w-64 transform border-r border-ivory-200 bg-white transition-transform duration-300 lg:translate-x-0 ${
          sidebarOpen ? 'translate-x-0' : '-translate-x-full'
        }`}
      >
        <div className="flex items-center justify-between border-b border-ivory-200 px-6 py-5">
          <Link to="/admin" className="flex flex-col leading-none">
            <span className="font-serif text-2xl font-semibold text-charcoal-900">{BRAND.name}</span>
            <span className="text-[0.6rem] font-medium uppercase tracking-[0.25em] text-champagne-500">
              Admin Panel
            </span>
          </Link>
          <button
            onClick={() => setSidebarOpen(false)}
            className="rounded-lg p-1 text-charcoal-900 hover:bg-ivory-100 lg:hidden"
          >
            <X size={20} />
          </button>
        </div>

        <nav className="flex flex-col gap-1 p-4">
          {navItems.map((item) => (
            <NavLink
              key={item.to}
              to={item.to}
              end={item.end}
              onClick={() => setSidebarOpen(false)}
              className={({ isActive }) =>
                `flex items-center gap-3 rounded-xl px-4 py-3 text-sm font-medium transition-colors ${
                  isActive
                    ? 'bg-champagne-100 text-champagne-600'
                    : 'text-charcoal-800 hover:bg-ivory-100'
                }`
              }
            >
              <item.icon size={18} />
              {item.label}
            </NavLink>
          ))}
        </nav>

        <div className="absolute inset-x-0 bottom-0 border-t border-ivory-200 p-4">
          <Link
            to="/"
            target="_blank"
            className="mb-2 flex items-center gap-3 rounded-xl px-4 py-2.5 text-sm font-medium text-charcoal-800 transition-colors hover:bg-ivory-100"
          >
            <ExternalLink size={18} />
            View Website
          </Link>
          <button
            onClick={handleSignOut}
            className="flex w-full items-center gap-3 rounded-xl px-4 py-2.5 text-sm font-medium text-red-600 transition-colors hover:bg-red-50"
          >
            <LogOut size={18} />
            Sign Out
          </button>
        </div>
      </aside>

      {/* Overlay */}
      {sidebarOpen && (
        <div
          className="fixed inset-0 z-30 bg-charcoal-900/30 lg:hidden"
          onClick={() => setSidebarOpen(false)}
        />
      )}

      {/* Main content */}
      <main className="lg:ml-64">
        <div className="px-5 py-8 sm:px-8 lg:px-12">
          <h1 className="mb-8 font-serif text-3xl font-medium text-charcoal-900">{title}</h1>
          {children}
        </div>
      </main>
    </div>
  );
}
