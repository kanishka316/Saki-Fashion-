import { useState, type KeyboardEvent } from 'react';
import { X } from 'lucide-react';

type Props = {
  value: string[];
  onChange: (colours: string[]) => void;
};

const suggestions = ['Red', 'Blue', 'Green', 'Gold', 'Cream', 'Pink', 'Maroon', 'Black', 'White', 'Yellow', 'Orange', 'Purple', 'Teal', 'Grey', 'Brown'];

export default function ColourTagInput({ value, onChange }: Props) {
  const [input, setInput] = useState('');

  const addColour = (colour: string) => {
    const trimmed = colour.trim();
    if (trimmed && !value.includes(trimmed)) {
      onChange([...value, trimmed]);
    }
    setInput('');
  };

  const removeColour = (colour: string) => {
    onChange(value.filter((c) => c !== colour));
  };

  const handleKeyDown = (e: KeyboardEvent<HTMLInputElement>) => {
    if (e.key === 'Enter' || e.key === ',') {
      e.preventDefault();
      addColour(input);
    } else if (e.key === 'Backspace' && input === '' && value.length > 0) {
      removeColour(value[value.length - 1]);
    }
  };

  const availableSuggestions = suggestions.filter((s) => !value.includes(s));

  return (
    <div>
      <label className="label-luxe">Available Colours</label>
      <div className="flex min-h-[42px] flex-wrap items-center gap-2 rounded-xl border border-ivory-300 bg-white px-3 py-2 transition-all focus-within:border-champagne-400 focus-within:ring-2 focus-within:ring-champagne-200">
        {value.map((c) => (
          <span
            key={c}
            className="inline-flex items-center gap-1 rounded-full bg-champagne-100 px-3 py-1 text-sm text-charcoal-900"
          >
            {c}
            <button
              type="button"
              onClick={() => removeColour(c)}
              className="text-champagne-600 hover:text-champagne-700"
            >
              <X size={13} />
            </button>
          </span>
        ))}
        <input
          type="text"
          value={input}
          onChange={(e) => setInput(e.target.value)}
          onKeyDown={handleKeyDown}
          onBlur={() => input && addColour(input)}
          placeholder={value.length === 0 ? 'Type a colour and press Enter' : ''}
          className="flex-1 border-0 bg-transparent text-sm text-charcoal-900 placeholder:text-beige-400 focus:outline-none"
        />
      </div>
      {availableSuggestions.length > 0 && (
        <div className="mt-2 flex flex-wrap gap-1.5">
          {availableSuggestions.slice(0, 8).map((s) => (
            <button
              key={s}
              type="button"
              onClick={() => addColour(s)}
              className="rounded-full border border-ivory-300 px-2.5 py-0.5 text-xs text-charcoal-800/70 transition-colors hover:border-champagne-400 hover:text-champagne-600"
            >
              + {s}
            </button>
          ))}
        </div>
      )}
    </div>
  );
}
