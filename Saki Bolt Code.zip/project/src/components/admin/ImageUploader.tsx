import { useRef, useState } from 'react';
import { Upload, X, GripVertical, Image as ImageIcon } from 'lucide-react';
import { uploadProductImage, deleteProductImage } from '../../lib/storage';

type Props = {
  productId: string;
  images: string[];
  onChange: (images: string[]) => void;
};

export default function ImageUploader({ productId, images, onChange }: Props) {
  const inputRef = useRef<HTMLInputElement>(null);
  const [uploading, setUploading] = useState(false);
  const [dragIndex, setDragIndex] = useState<number | null>(null);

  const handleFiles = async (files: FileList | null) => {
    if (!files || files.length === 0) return;
    const remaining = 10 - images.length;
    if (remaining <= 0) return;
    const toUpload = Array.from(files).slice(0, remaining);
    setUploading(true);

    const uploaded: string[] = [];
    for (const file of toUpload) {
      const url = await uploadProductImage(file, productId);
      if (url) uploaded.push(url);
    }

    onChange([...images, ...uploaded]);
    setUploading(false);
    if (inputRef.current) inputRef.current.value = '';
  };

  const handleDelete = async (index: number) => {
    const url = images[index];
    await deleteProductImage(url);
    onChange(images.filter((_, i) => i !== index));
  };

  const handleReplace = async (index: number, file: File | null) => {
    if (!file) return;
    setUploading(true);
    const oldUrl = images[index];
    const newUrl = await uploadProductImage(file, productId);
    if (newUrl) {
      const next = [...images];
      next[index] = newUrl;
      onChange(next);
      await deleteProductImage(oldUrl);
    }
    setUploading(false);
  };

  const handleDragStart = (index: number) => setDragIndex(index);
  const handleDrop = (index: number) => {
    if (dragIndex === null || dragIndex === index) return;
    const next = [...images];
    const [moved] = next.splice(dragIndex, 1);
    next.splice(index, 0, moved);
    onChange(next);
    setDragIndex(null);
  };

  return (
    <div>
      <div className="mb-2 flex items-center justify-between">
        <label className="label-luxe">
          Product Images <span className="text-beige-400">(First image = cover)</span>
        </label>
        <span className="text-xs text-beige-500">{images.length}/10</span>
      </div>

      {/* Upload dropzone */}
      {images.length < 10 && (
        <button
          type="button"
          onClick={() => inputRef.current?.click()}
          disabled={uploading}
          className="flex w-full flex-col items-center justify-center gap-2 rounded-xl border-2 border-dashed border-ivory-300 bg-ivory-50 py-8 text-charcoal-800/60 transition-colors hover:border-champagne-400 hover:bg-champagne-50 disabled:opacity-50"
        >
          {uploading ? (
            <span className="text-sm">Uploading...</span>
          ) : (
            <>
              <Upload size={24} className="text-champagne-400" />
              <span className="text-sm font-medium">Click to upload images</span>
              <span className="text-xs text-beige-500">Up to 10 images</span>
            </>
          )}
        </button>
      )}
      <input
        ref={inputRef}
        type="file"
        accept="image/*"
        multiple
        className="hidden"
        onChange={(e) => handleFiles(e.target.files)}
      />

      {/* Image grid */}
      {images.length > 0 && (
        <div className="mt-4 grid grid-cols-2 gap-3 sm:grid-cols-3 md:grid-cols-4">
          {images.map((img, i) => (
            <div
              key={i}
              draggable
              onDragStart={() => handleDragStart(i)}
              onDragOver={(e) => e.preventDefault()}
              onDrop={() => handleDrop(i)}
              className={`group relative aspect-[3/4] overflow-hidden rounded-lg border-2 bg-ivory-100 ${
                i === 0 ? 'border-champagne-400' : 'border-ivory-300'
              } ${dragIndex === i ? 'opacity-40' : ''}`}
            >
              <img src={img} alt={`Image ${i + 1}`} className="h-full w-full object-cover" />
              {i === 0 && (
                <span className="absolute left-1.5 top-1.5 rounded-full bg-champagne-400 px-2 py-0.5 text-[0.55rem] font-medium uppercase tracking-wide text-charcoal-900">
                  Cover
                </span>
              )}
              <div className="absolute inset-0 flex items-center justify-center gap-2 bg-charcoal-900/50 opacity-0 transition-opacity group-hover:opacity-100">
                <button
                  type="button"
                  onClick={() => handleDelete(i)}
                  className="rounded-full bg-red-500 p-2 text-white transition-colors hover:bg-red-600"
                  title="Delete image"
                >
                  <X size={14} />
                </button>
                <button
                  type="button"
                  onClick={() => {
                    const input = document.createElement('input');
                    input.type = 'file';
                    input.accept = 'image/*';
                    input.onchange = (e) => handleReplace(i, (e.target as HTMLInputElement).files?.[0] ?? null);
                    input.click();
                  }}
                  className="rounded-full bg-champagne-400 p-2 text-charcoal-900 transition-colors hover:bg-champagne-300"
                  title="Replace image"
                >
                  <ImageIcon size={14} />
                </button>
              </div>
              <div className="absolute bottom-1.5 left-1.5 cursor-grab rounded-full bg-ivory-50/80 p-1 text-charcoal-900">
                <GripVertical size={12} />
              </div>
              <span className="absolute bottom-1.5 right-1.5 rounded-full bg-ivory-50/80 px-1.5 py-0.5 text-[0.55rem] text-charcoal-900">
                {i + 1}
              </span>
            </div>
          ))}
        </div>
      )}
      {images.length === 0 && !uploading && (
        <p className="mt-2 text-xs text-beige-400">No images uploaded yet.</p>
      )}
    </div>
  );
}
