import { MessageCircle, Instagram } from 'lucide-react';
import { CONTACT } from '../lib/constants';

export default function FloatingSocial() {
  return (
    <div className="fixed bottom-6 right-6 z-40 flex flex-col gap-3">
      <a
        href={`https://wa.me/${CONTACT.whatsapp}`}
        target="_blank"
        rel="noreferrer"
        className="group flex h-12 w-12 items-center justify-center rounded-full bg-green-500 text-white shadow-luxe transition-all duration-300 hover:scale-110 hover:bg-green-600"
        aria-label="WhatsApp"
        title="WhatsApp"
      >
        <MessageCircle size={20} />
      </a>
      <a
        href={CONTACT.instagram}
        target="_blank"
        rel="noreferrer"
        className="group flex h-12 w-12 items-center justify-center rounded-full bg-pink-500 text-white shadow-luxe transition-all duration-300 hover:scale-110 hover:bg-pink-600"
        aria-label="Instagram"
        title="Instagram"
      >
        <Instagram size={20} />
      </a>
    </div>
  );
}
