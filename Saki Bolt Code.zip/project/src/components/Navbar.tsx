import { useEffect, useState } from 'react';
import { Link, NavLink, useLocation } from 'react-router-dom';
import { Menu, X, Phone } from 'lucide-react';
import { BRAND, CONTACT } from '../lib/constants';

const navLinks = [
  { to: '/', label: 'Home' },
  { to: '/collections', label: 'Collections' },
  { to: '/gallery', label: 'Gallery' },
  { to: '/about', label: 'About Us' },
  { to: '/contact', label: 'Contact' },
];

export default function Navbar() {
  const [scrolled, setScrolled] = useState(false);
  const [open, setOpen] = useState(false);
  const location = useLocation();

  useEffect(() => {
    const onScroll = () => setScrolled(window.scrollY > 20);
    onScroll();
    window.addEventListener('scroll', onScroll);
    return () => window.removeEventListener('scroll', onScroll);
  }, []);

  useEffect(() => {
    setOpen(false);
  }, [location.pathname]);

  return (
    <header
      className={`fixed inset-x-0 top-0 z-50 transition-all duration-500 ${
        scrolled
          ? 'bg-ivory-50/90 shadow-soft backdrop-blur-md'
          : 'bg-transparent'
      }`}
    >
      <nav className="container-luxe flex items-center justify-between py-4">
        <Link to="/" className="group flex flex-col leading-none">
          <span className="font-serif text-2xl font-semibold tracking-wide text-charcoal-900 transition-colors group-hover:text-champagne-500">
            {BRAND.name}
          </span>
          <span className="text-[0.6rem] font-medium uppercase tracking-[0.3em] text-champagne-500">
            {BRAND.tagline}
          </span>
        </Link>

        <div className="hidden items-center gap-1 md:flex">
          {navLinks.map((link) => (
            <NavLink
              key={link.to}
              to={link.to}
              end={link.to === '/'}
              className={({ isActive }) =>
                `btn-ghost ${isActive ? 'text-champagne-500' : ''}`
              }
            >
              {link.label}
            </NavLink>
          ))}
        </div>

        <div className="hidden md:block">
          <a
            href={`tel:${CONTACT.phoneRaw}`}
            className="inline-flex items-center gap-2 rounded-full border border-champagne-400 px-4 py-2 text-xs font-medium uppercase tracking-[0.15em] text-charcoal-900 transition-all hover:bg-champagne-400 hover:text-ivory-50"
          >
            <Phone size={14} />
            Call
          </a>
        </div>

        <button
          onClick={() => setOpen((v) => !v)}
          className="rounded-full p-2 text-charcoal-900 transition-colors hover:text-champagne-500 md:hidden"
          aria-label="Toggle menu"
        >
          {open ? <X size={24} /> : <Menu size={24} />}
        </button>
      </nav>

      {/* Mobile menu */}
      <div
        className={`overflow-hidden transition-all duration-500 md:hidden ${
          open ? 'max-h-96' : 'max-h-0'
        }`}
      >
        <div className="container-luxe flex flex-col gap-1 border-t border-ivory-200 py-4">
          {navLinks.map((link) => (
            <NavLink
              key={link.to}
              to={link.to}
              end={link.to === '/'}
              className={({ isActive }) =>
                `rounded-lg px-4 py-3 text-sm font-medium uppercase tracking-[0.12em] transition-colors ${
                  isActive
                    ? 'bg-champagne-100 text-champagne-600'
                    : 'text-charcoal-800 hover:bg-ivory-100'
                }`
              }
            >
              {link.label}
            </NavLink>
          ))}
          <a
            href={`tel:${CONTACT.phoneRaw}`}
            className="mt-2 inline-flex items-center justify-center gap-2 rounded-full bg-charcoal-900 px-4 py-3 text-xs font-medium uppercase tracking-[0.15em] text-ivory-50"
          >
            <Phone size={14} />
            Call Boutique
          </a>
        </div>
      </div>
    </header>
  );
}
