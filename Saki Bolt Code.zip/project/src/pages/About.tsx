import { Link } from 'react-router-dom';
import { ArrowRight, Gem, Sparkles, Heart, Truck } from 'lucide-react';
import Reveal from '../components/Reveal';
import { BRAND } from '../lib/constants';

const values = [
  { icon: Gem, title: 'Premium Quality', desc: 'Every piece is hand-selected for fabric, finish and craftsmanship.' },
  { icon: Sparkles, title: 'Latest Collections', desc: 'We refresh our boutique every season with the newest styles.' },
  { icon: Heart, title: 'Affordable Boutique Fashion', desc: 'Luxury aesthetics at prices that respect your budget.' },
  { icon: Truck, title: 'Friendly Service', desc: 'Personalised guidance to help you find your perfect look.' },
];

export default function About() {
  return (
    <div className="pt-28">
      {/* Hero */}
      <section className="container-luxe py-12">
        <div className="grid items-center gap-12 md:grid-cols-2">
          <Reveal>
            <p className="section-eyebrow">Our Story</p>
            <h1 className="mt-3 text-5xl font-medium text-charcoal-900 md:text-6xl">
              Elegance, Woven into Every Thread
            </h1>
            <p className="mt-6 text-base leading-relaxed text-charcoal-800/80">
              {BRAND.full} was born from a love for timeless Indian fashion. Nestled in the textile
              city of Tirupur, our boutique brings together a handpicked collection of sarees
              and dress materials — each piece celebrating the rich heritage of
              Indian craftsmanship.
            </p>
            <p className="mt-4 text-base leading-relaxed text-charcoal-800/80">
              We believe fashion is more than clothing — it's an expression of who you are. That's
              why we curate pieces that blend tradition with modern sensibility, so every woman
              can find something that feels truly hers.
            </p>
            <Link to="/collections" className="btn-outline mt-8">
              Explore Collections <ArrowRight size={16} />
            </Link>
          </Reveal>
          <Reveal delay={150}>
            <div className="overflow-hidden rounded-3xl shadow-luxe">
              <img
                src="https://images.pexels.com/photos/29049358/pexels-photo-29049358.jpeg?auto=compress&cs=tinysrgb&w=800"
                alt="Saki Boutique interior"
                className="h-[500px] w-full object-cover image-zoom"
              />
            </div>
          </Reveal>
        </div>
      </section>

      {/* Values */}
      <section className="bg-ivory-100 py-24">
        <div className="container-luxe">
          <Reveal>
            <div className="text-center">
              <p className="section-eyebrow">Our Promise</p>
              <h2 className="mt-3 text-4xl font-medium text-charcoal-900 md:text-5xl">
                Why Choose Saki
              </h2>
            </div>
          </Reveal>
          <div className="mt-14 grid gap-6 sm:grid-cols-2 lg:grid-cols-4">
            {values.map((v, i) => (
              <Reveal key={v.title} delay={i * 100}>
                <div className="card-luxe hover-luxe h-full p-8 text-center hover:shadow-luxe">
                  <div className="mx-auto flex h-14 w-14 items-center justify-center rounded-full bg-champagne-100 text-champagne-500">
                    <v.icon size={24} />
                  </div>
                  <h3 className="mt-5 font-serif text-xl font-medium text-charcoal-900">{v.title}</h3>
                  <p className="mt-2 text-sm leading-relaxed text-charcoal-800/70">{v.desc}</p>
                </div>
              </Reveal>
            ))}
          </div>
        </div>
      </section>

      {/* Quote */}
      <section className="container-luxe py-24">
        <Reveal>
          <div className="mx-auto max-w-3xl text-center">
            <p className="font-serif text-3xl font-medium italic leading-relaxed text-charcoal-900 md:text-4xl">
              "Every woman deserves to feel elegant. Our mission is to make that feeling
              accessible — one beautiful piece at a time."
            </p>
            <p className="mt-6 text-xs font-medium uppercase tracking-[0.3em] text-champagne-500">
              — The Saki Family
            </p>
          </div>
        </Reveal>
      </section>
    </div>
  );
}
