import { useRef, useState } from 'react';
import { Upload, X, ImageIcon } from 'lucide-react';
import AdminLayout from '../../components/admin/AdminLayout';
import { useGalleryImages } from '../../lib/useGallery';
import { supabase } from '../../lib/supabase';
import { uploadGalleryImage, deleteProductImage } from '../../lib/storage';

export default function AdminGallery() {
  const { images, loading } = useGalleryImages();
  const inputRef = useRef<HTMLInputElement>(null);
  const [uploading, setUploading] = useState(false);

  const handleUpload = async (files: FileList | null) => {
    if (!files || files.length === 0) return;
    setUploading(true);
    for (const file of Array.from(files)) {
      const url = await uploadGalleryImage(file);
      if (url) {
        await supabase.from('gallery_images').insert({
          url,
          sort_order: images.length,
        });
      }
    }
    setUploading(false);
    if (inputRef.current) inputRef.current.value = '';
  };

  const handleDelete = async (id: string, url: string) => {
    if (!confirm('Delete this gallery image?')) return;
    await deleteProductImage(url);
    await supabase.from('gallery_images').delete().eq('id', id);
  };

  return (
    <AdminLayout title="Gallery">
      <div className="mb-6">
        <button
          onClick={() => inputRef.current?.click()}
          disabled={uploading}
          className="btn-primary disabled:opacity-50"
        >
          <Upload size={16} />
          {uploading ? 'Uploading...' : 'Upload Images'}
        </button>
        <input
          ref={inputRef}
          type="file"
          accept="image/*"
          multiple
          className="hidden"
          onChange={(e) => handleUpload(e.target.files)}
        />
      </div>

      {loading ? (
        <div className="grid grid-cols-2 gap-4 sm:grid-cols-3 lg:grid-cols-4">
          {[...Array(6)].map((_, i) => (
            <div key={i} className="skeleton h-48 rounded-xl" />
          ))}
        </div>
      ) : images.length === 0 ? (
        <div className="rounded-xl bg-ivory-100 p-12 text-center">
          <ImageIcon size={32} className="mx-auto text-beige-400" />
          <p className="mt-3 text-charcoal-800/60">No gallery images yet.</p>
        </div>
      ) : (
        <div className="grid grid-cols-2 gap-4 sm:grid-cols-3 lg:grid-cols-4">
          {images.map((img) => (
            <div key={img.id} className="group relative aspect-square overflow-hidden rounded-xl shadow-soft">
              <img src={img.url} alt={img.label ?? 'Gallery'} className="h-full w-full object-cover" />
              <button
                onClick={() => handleDelete(img.id, img.url)}
                className="absolute right-2 top-2 rounded-full bg-red-500 p-2 text-white opacity-0 transition-opacity group-hover:opacity-100"
              >
                <X size={14} />
              </button>
            </div>
          ))}
        </div>
      )}
    </AdminLayout>
  );
}
