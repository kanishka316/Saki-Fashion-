import { useState, useEffect, type FormEvent } from 'react';
import { useNavigate, useParams } from 'react-router-dom';
import { ArrowLeft, Save } from 'lucide-react';
import AdminLayout from '../../components/admin/AdminLayout';
import ImageUploader from '../../components/admin/ImageUploader';
import ColourTagInput from '../../components/admin/ColourTagInput';
import { useCategories, useSubcategoriesByMain } from '../../lib/useCategories';
import { supabase } from '../../lib/supabase';
import type { Product } from '../../lib/supabase';

export default function AdminProductForm() {
  const { id } = useParams<{ id: string }>();
  const navigate = useNavigate();
  const isEdit = Boolean(id);
  const { mainCategories } = useCategories();

  const [name, setName] = useState('');
  const [productCode, setProductCode] = useState('');
  const [mainCategoryId, setMainCategoryId] = useState('');
  const [subcategoryId, setSubcategoryId] = useState('');
  const [fabric, setFabric] = useState('');
  const [description, setDescription] = useState('');
  const [colours, setColours] = useState<string[]>([]);
  const [images, setImages] = useState<string[]>([]);
  const [availability, setAvailability] = useState<Product['availability']>('In Stock');
  const [price, setPrice] = useState(0);
  const [isNewArrival, setIsNewArrival] = useState(false);
  const [sortOrder, setSortOrder] = useState(0);
  const [saving, setSaving] = useState(false);
  const [error, setError] = useState<string | null>(null);
  const [loadingProduct, setLoadingProduct] = useState(isEdit);

  const { subcategories } = useSubcategoriesByMain(mainCategoryId);

  useEffect(() => {
    if (!isEdit || !id) return;
    supabase
      .from('products')
      .select('*')
      .eq('id', id)
      .maybeSingle()
      .then(({ data }) => {
        if (data) {
          const p = data as Product;
          setName(p.name);
          setProductCode(p.product_code);
          setMainCategoryId(p.main_category_id);
          setSubcategoryId(p.subcategory_id ?? '');
          setFabric(p.fabric ?? '');
          setDescription(p.description ?? '');
          setColours(p.colours ?? []);
          setImages(p.images ?? []);
          setAvailability(p.availability);
          setPrice(p.price ?? 0);
          setIsNewArrival(p.is_new_arrival);
          setSortOrder(p.sort_order);
        }
        setLoadingProduct(false);
      });
  }, [id, isEdit]);

  const handleSubmit = async (e: FormEvent) => {
    e.preventDefault();
    setError(null);
    setSaving(true);

    if (!name || !productCode || !mainCategoryId) {
      setError('Name, product code, and category are required.');
      setSaving(false);
      return;
    }

    const payload = {
      name,
      product_code: productCode,
      main_category_id: mainCategoryId,
      subcategory_id: subcategoryId || null,
      fabric: fabric || null,
      description: description || null,
      colours,
      images,
      availability,
      price,
      is_new_arrival: isNewArrival,
      sort_order: sortOrder,
    };

    let result;
    if (isEdit && id) {
      result = await supabase.from('products').update(payload).eq('id', id);
    } else {
      result = await supabase.from('products').insert(payload).select().single();
    }

    if (result.error) {
      setError(result.error.message);
      setSaving(false);
    } else {
      navigate('/admin/products');
    }
  };

  if (loadingProduct) {
    return (
      <AdminLayout title="Edit Product">
        <div className="space-y-4">
          <div className="skeleton h-12 rounded-xl" />
          <div className="skeleton h-64 rounded-xl" />
        </div>
      </AdminLayout>
    );
  }

  return (
    <AdminLayout title={isEdit ? 'Edit Product' : 'Add Product'}>
      <button
        onClick={() => navigate('/admin/products')}
        className="mb-6 inline-flex items-center gap-2 text-sm text-charcoal-800/70 transition-colors hover:text-champagne-500"
      >
        <ArrowLeft size={16} /> Back to Products
      </button>

      <form onSubmit={handleSubmit} className="max-w-3xl space-y-6">
        {error && (
          <div className="rounded-lg bg-red-50 px-4 py-3 text-sm text-red-600">{error}</div>
        )}

        <div className="card-luxe space-y-5 p-6">
          <div>
            <label className="label-luxe">Product Name *</label>
            <input
              type="text"
              required
              value={name}
              onChange={(e) => setName(e.target.value)}
              className="input-luxe"
              placeholder="e.g. Royal Blue Kanchipuram Silk Saree"
            />
          </div>

          <div className="grid gap-5 sm:grid-cols-2">
            <div>
              <label className="label-luxe">Product Code *</label>
              <input
                type="text"
                required
                value={productCode}
                onChange={(e) => setProductCode(e.target.value)}
                className="input-luxe"
                placeholder="e.g. SKR-SR-001"
              />
            </div>
            <div>
              <label className="label-luxe">Fabric</label>
              <input
                type="text"
                value={fabric}
                onChange={(e) => setFabric(e.target.value)}
                className="input-luxe"
                placeholder="e.g. Pure Silk"
              />
            </div>
          </div>

          <div className="grid gap-5 sm:grid-cols-2">
            <div>
              <label className="label-luxe">Main Category *</label>
              <select
                required
                value={mainCategoryId}
                onChange={(e) => {
                  setMainCategoryId(e.target.value);
                  setSubcategoryId('');
                }}
                className="input-luxe"
              >
                <option value="">Select category</option>
                {mainCategories.map((c) => (
                  <option key={c.id} value={c.id}>
                    {c.name}
                  </option>
                ))}
              </select>
            </div>
            <div>
              <label className="label-luxe">Sub Category</label>
              <select
                value={subcategoryId}
                onChange={(e) => setSubcategoryId(e.target.value)}
                className="input-luxe"
                disabled={!mainCategoryId}
              >
                <option value="">None</option>
                {subcategories.map((s) => (
                  <option key={s.id} value={s.id}>
                    {s.name}
                  </option>
                ))}
              </select>
            </div>
          </div>

          <div>
            <label className="label-luxe">Description</label>
            <textarea
              value={description}
              onChange={(e) => setDescription(e.target.value)}
              rows={4}
              className="input-luxe resize-none"
              placeholder="Product description..."
            />
          </div>

          <ColourTagInput value={colours} onChange={setColours} />

          <div className="grid gap-5 sm:grid-cols-2">
            <div>
              <label className="label-luxe">Availability</label>
              <select
                value={availability}
                onChange={(e) => setAvailability(e.target.value as Product['availability'])}
                className="input-luxe"
              >
                <option value="In Stock">In Stock</option>
                <option value="Limited Stock">Limited Stock</option>
                <option value="Out of Stock">Out of Stock</option>
              </select>
            </div>
            <div>
              <label className="label-luxe">Price (₹)</label>
              <input
                type="number"
                min="0"
                step="0.01"
                value={price}
                onChange={(e) => setPrice(Number(e.target.value))}
                className="input-luxe"
                placeholder="0.00"
              />
            </div>
            <div>
              <label className="label-luxe">Sort Order</label>
              <input
                type="number"
                value={sortOrder}
                onChange={(e) => setSortOrder(Number(e.target.value))}
                className="input-luxe"
              />
            </div>
          </div>

          <label className="flex items-center gap-3">
            <input
              type="checkbox"
              checked={isNewArrival}
              onChange={(e) => setIsNewArrival(e.target.checked)}
              className="h-5 w-5 rounded border-ivory-300 text-champagne-500 focus:ring-champagne-400"
            />
            <span className="text-sm text-charcoal-900">Mark as New Arrival</span>
          </label>
        </div>

        <div className="card-luxe p-6">
          <ImageUploader
            productId={id ?? `temp-${Date.now()}`}
            images={images}
            onChange={setImages}
          />
        </div>

        <div className="flex gap-3">
          <button type="submit" disabled={saving} className="btn-primary disabled:opacity-50">
            <Save size={16} />
            {saving ? 'Saving...' : isEdit ? 'Update Product' : 'Create Product'}
          </button>
          <button
            type="button"
            onClick={() => navigate('/admin/products')}
            className="btn-ghost"
          >
            Cancel
          </button>
        </div>
      </form>
    </AdminLayout>
  );
}
