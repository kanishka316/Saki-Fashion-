import { useEffect, useState } from 'react';
import { Link } from 'react-router-dom';
import { Package, Tags, Boxes, TrendingUp, ArrowRight } from 'lucide-react';
import AdminLayout from '../../components/admin/AdminLayout';
import { supabase, type Product } from '../../lib/supabase';

export default function AdminDashboard() {
  const [stats, setStats] = useState({
    products: 0,
    categories: 0,
    inStock: 0,
    newArrivals: 0,
    gallery: 0,
  });
  const [recentProducts, setRecentProducts] = useState<Product[]>([]);
  const [loading, setLoading] = useState(true);

  useEffect(() => {
    async function load() {
      const [{ count: products }, { count: categories }, { count: gallery }, { count: inStock }, { count: newArrivals }, { data: recent }] =
        await Promise.all([
          supabase.from('products').select('*', { count: 'exact', head: true }),
          supabase.from('main_categories').select('*', { count: 'exact', head: true }),
          supabase.from('gallery_images').select('*', { count: 'exact', head: true }),
          supabase.from('products').select('*', { count: 'exact', head: true }).eq('availability', 'In Stock'),
          supabase.from('products').select('*', { count: 'exact', head: true }).eq('is_new_arrival', true),
          supabase.from('products').select('*').order('created_at', { ascending: false }).limit(5),
        ]);

      setStats({
        products: products ?? 0,
        categories: categories ?? 0,
        inStock: inStock ?? 0,
        newArrivals: newArrivals ?? 0,
        gallery: gallery ?? 0,
      });
      setRecentProducts((recent ?? []) as Product[]);
      setLoading(false);
    }
    load();
  }, []);

  const cards = [
    { label: 'Total Products', value: stats.products, icon: Package, color: 'bg-champagne-100 text-champagne-600' },
    { label: 'Categories', value: stats.categories, icon: Tags, color: 'bg-blue-100 text-blue-600' },
    { label: 'In Stock', value: stats.inStock, icon: Boxes, color: 'bg-green-100 text-green-600' },
    { label: 'New Arrivals', value: stats.newArrivals, icon: TrendingUp, color: 'bg-pink-100 text-pink-600' },
  ];

  return (
    <AdminLayout title="Dashboard">
      <div className="grid gap-4 sm:grid-cols-2 lg:grid-cols-4">
        {cards.map((card) => (
          <div key={card.label} className="card-luxe p-6">
            <div className={`flex h-12 w-12 items-center justify-center rounded-xl ${card.color}`}>
              <card.icon size={22} />
            </div>
            <p className="mt-4 text-3xl font-semibold text-charcoal-900">
              {loading ? '—' : card.value}
            </p>
            <p className="text-sm text-charcoal-800/60">{card.label}</p>
          </div>
        ))}
      </div>

      {/* Quick actions */}
      <div className="mt-8 grid gap-4 sm:grid-cols-2 lg:grid-cols-3">
        <Link to="/admin/products/new" className="card-luxe hover-luxe group flex items-center justify-between p-6 hover:shadow-luxe">
          <div>
            <p className="font-serif text-lg font-medium text-charcoal-900">Add Product</p>
            <p className="text-sm text-charcoal-800/60">Upload a new product</p>
          </div>
          <ArrowRight size={20} className="text-champagne-500 transition-transform group-hover:translate-x-1" />
        </Link>
        <Link to="/admin/gallery" className="card-luxe hover-luxe group flex items-center justify-between p-6 hover:shadow-luxe">
          <div>
            <p className="font-serif text-lg font-medium text-charcoal-900">Manage Gallery</p>
            <p className="text-sm text-charcoal-800/60">{stats.gallery} images</p>
          </div>
          <ArrowRight size={20} className="text-champagne-500 transition-transform group-hover:translate-x-1" />
        </Link>
        <Link to="/admin/stock" className="card-luxe hover-luxe group flex items-center justify-between p-6 hover:shadow-luxe">
          <div>
            <p className="font-serif text-lg font-medium text-charcoal-900">Stock Management</p>
            <p className="text-sm text-charcoal-800/60">Update availability</p>
          </div>
          <ArrowRight size={20} className="text-champagne-500 transition-transform group-hover:translate-x-1" />
        </Link>
      </div>

      {/* Recent products */}
      <div className="mt-8">
        <h2 className="mb-4 font-serif text-xl font-medium text-charcoal-900">Recent Products</h2>
        {loading ? (
          <div className="space-y-2">
            {[...Array(3)].map((_, i) => (
              <div key={i} className="skeleton h-16 rounded-xl" />
            ))}
          </div>
        ) : recentProducts.length === 0 ? (
          <p className="rounded-xl bg-ivory-100 p-8 text-center text-charcoal-800/60">
            No products yet. Click "Add Product" to get started.
          </p>
        ) : (
          <div className="space-y-2">
            {recentProducts.map((p) => (
              <Link
                key={p.id}
                to={`/admin/products/${p.id}`}
                className="card-luxe flex items-center gap-4 p-4 hover:shadow-soft"
              >
                <div className="h-14 w-12 shrink-0 overflow-hidden rounded-lg bg-ivory-100">
                  {p.images[0] ? (
                    <img src={p.images[0]} alt={p.name} className="h-full w-full object-cover" />
                  ) : (
                    <div className="flex h-full w-full items-center justify-center text-beige-400">
                      <Package size={18} />
                    </div>
                  )}
                </div>
                <div className="flex-1">
                  <p className="font-medium text-charcoal-900">{p.name}</p>
                  <p className="text-xs text-beige-500">{p.product_code}</p>
                </div>
                <span className={`rounded-full px-3 py-1 text-xs ${
                  p.availability === 'In Stock' ? 'bg-green-100 text-green-700' :
                  p.availability === 'Limited Stock' ? 'bg-champagne-200 text-champagne-700' :
                  'bg-red-100 text-red-600'
                }`}>
                  {p.availability}
                </span>
              </Link>
            ))}
          </div>
        )}
      </div>
    </AdminLayout>
  );
}
