import { useState } from 'react';
import { Link } from 'react-router-dom';
import { Plus, Search, Pencil, Trash2 } from 'lucide-react';
import AdminLayout from '../../components/admin/AdminLayout';
import { useProducts } from '../../lib/useProducts';

import { supabase, type Product } from '../../lib/supabase';
import { deleteProductImage } from '../../lib/storage';

export default function AdminProducts() {
  const [search, setSearch] = useState('');
  const { products, loading } = useProducts({ search });

  const handleDelete = async (product: Product) => {
    if (!confirm(`Delete "${product.name}"? This cannot be undone.`)) return;
    for (const url of product.images) {
      await deleteProductImage(url);
    }
    await supabase.from('products').delete().eq('id', product.id);
  };

  return (
    <AdminLayout title="Products">
      <div className="mb-6 flex flex-col gap-4 sm:flex-row sm:items-center sm:justify-between">
        <div className="relative flex-1 sm:max-w-xs">
          <Search size={18} className="absolute left-3 top-1/2 -translate-y-1/2 text-beige-400" />
          <input
            type="text"
            placeholder="Search products..."
            value={search}
            onChange={(e) => setSearch(e.target.value)}
            className="input-luxe pl-10"
          />
        </div>
        <Link to="/admin/products/new" className="btn-primary">
          <Plus size={16} /> Add Product
        </Link>
      </div>

      {loading ? (
        <div className="space-y-3">
          {[...Array(5)].map((_, i) => (
            <div key={i} className="skeleton h-20 rounded-xl" />
          ))}
        </div>
      ) : products.length === 0 ? (
        <div className="rounded-xl bg-ivory-100 p-12 text-center">
          <p className="text-charcoal-800/60">No products found.</p>
          <Link to="/admin/products/new" className="btn-outline mt-4">
            <Plus size={16} /> Add your first product
          </Link>
        </div>
      ) : (
        <div className="overflow-hidden rounded-xl border border-ivory-200 bg-white shadow-soft">
          <table className="w-full">
            <thead className="border-b border-ivory-200 bg-ivory-50">
              <tr>
                <th className="px-4 py-3 text-left text-xs font-medium uppercase tracking-[0.1em] text-charcoal-800">Product</th>
                <th className="hidden px-4 py-3 text-left text-xs font-medium uppercase tracking-[0.1em] text-charcoal-800 sm:table-cell">Category</th>
                <th className="hidden px-4 py-3 text-left text-xs font-medium uppercase tracking-[0.1em] text-charcoal-800 md:table-cell">Code</th>
                <th className="hidden px-4 py-3 text-left text-xs font-medium uppercase tracking-[0.1em] text-charcoal-800 sm:table-cell">Price</th>
                <th className="px-4 py-3 text-left text-xs font-medium uppercase tracking-[0.1em] text-charcoal-800">Stock</th>
                <th className="px-4 py-3 text-right text-xs font-medium uppercase tracking-[0.1em] text-charcoal-800">Actions</th>
              </tr>
            </thead>
            <tbody className="divide-y divide-ivory-100">
              {products.map((p) => (
                <tr key={p.id} className="transition-colors hover:bg-ivory-50">
                  <td className="px-4 py-3">
                    <div className="flex items-center gap-3">
                      <div className="h-12 w-10 shrink-0 overflow-hidden rounded-lg bg-ivory-100">
                        {p.images[0] ? (
                          <img src={p.images[0]} alt={p.name} className="h-full w-full object-cover" />
                        ) : null}
                      </div>
                      <div>
                        <p className="font-medium text-charcoal-900">{p.name}</p>
                        {p.is_new_arrival && (
                          <span className="text-[0.6rem] font-medium uppercase tracking-wide text-champagne-500">New</span>
                        )}
                      </div>
                    </div>
                  </td>
                  <td className="hidden px-4 py-3 text-sm text-charcoal-800/70 sm:table-cell">
                    {p.main_category?.name ?? '—'}
                  </td>
                  <td className="hidden px-4 py-3 text-sm text-charcoal-800/70 md:table-cell">
                    {p.product_code}
                  </td>
                  <td className="hidden px-4 py-3 text-sm text-charcoal-800/70 sm:table-cell">
                    {p.price > 0 ? `₹${p.price.toLocaleString('en-IN')}` : '—'}
                  </td>
                  <td className="px-4 py-3">
                    <span className={`rounded-full px-2.5 py-1 text-xs ${
                      p.availability === 'In Stock' ? 'bg-green-100 text-green-700' :
                      p.availability === 'Limited Stock' ? 'bg-champagne-200 text-champagne-700' :
                      'bg-red-100 text-red-600'
                    }`}>
                      {p.availability}
                    </span>
                  </td>
                  <td className="px-4 py-3">
                    <div className="flex justify-end gap-2">
                      <Link
                        to={`/admin/products/${p.id}`}
                        className="rounded-lg p-2 text-charcoal-800 transition-colors hover:bg-champagne-100 hover:text-champagne-600"
                      >
                        <Pencil size={16} />
                      </Link>
                      <button
                        onClick={() => handleDelete(p)}
                        className="rounded-lg p-2 text-charcoal-800 transition-colors hover:bg-red-50 hover:text-red-600"
                      >
                        <Trash2 size={16} />
                      </button>
                    </div>
                  </td>
                </tr>
              ))}
            </tbody>
          </table>
        </div>
      )}
    </AdminLayout>
  );
}
