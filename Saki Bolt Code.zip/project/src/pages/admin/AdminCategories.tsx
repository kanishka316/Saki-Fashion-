import { useRef, useState } from 'react';
import { Plus, Trash2, ChevronDown, ChevronRight, Upload, X, Edit2 } from 'lucide-react';
import AdminLayout from '../../components/admin/AdminLayout';
import { useCategories } from '../../lib/useCategories';
import { supabase, type MainCategory, type Subcategory } from '../../lib/supabase';
import { uploadCollectionImage, deleteStorageImage } from '../../lib/storage';

const slugify = (s: string) =>
  s.toLowerCase().trim().replace(/[^a-z0-9]+/g, '-').replace(/^-|-$/g, '');

export default function AdminCategories() {
  const { mainCategories, subcategories, loading } = useCategories();
  const [expanded, setExpanded] = useState<Set<string>>(new Set());

  const [showAddMain, setShowAddMain] = useState(false);
  const [mainName, setMainName] = useState('');
  const [mainSlug, setMainSlug] = useState('');
  const [mainDesc, setMainDesc] = useState('');
  const [mainImage, setMainImage] = useState<string | null>(null);
  const [mainUploading, setMainUploading] = useState(false);
  const mainFileRef = useRef<HTMLInputElement>(null);

  const [editingMain, setEditingMain] = useState<MainCategory | null>(null);
  const [editMainName, setEditMainName] = useState('');
  const [editMainSlug, setEditMainSlug] = useState('');
  const [editMainDesc, setEditMainDesc] = useState('');
  const [editMainImage, setEditMainImage] = useState<string | null>(null);
  const [editMainUploading, setEditMainUploading] = useState(false);
  const editMainFileRef = useRef<HTMLInputElement>(null);

  const [showAdd, setShowAdd] = useState<string | null>(null);
  const [newSubName, setNewSubName] = useState('');
  const [newSubSlug, setNewSubSlug] = useState('');
  const [newSubImage, setNewSubImage] = useState<string | null>(null);
  const [newSubUploading, setNewSubUploading] = useState(false);
  const subFileRef = useRef<HTMLInputElement>(null);

  const [editingSub, setEditingSub] = useState<Subcategory | null>(null);
  const [editSubName, setEditSubName] = useState('');
  const [editSubSlug, setEditSubSlug] = useState('');
  const [editSubImage, setEditSubImage] = useState<string | null>(null);
  const [editSubUploading, setEditSubUploading] = useState(false);
  const editSubFileRef = useRef<HTMLInputElement>(null);

  const toggle = (id: string) => {
    setExpanded((prev) => {
      const next = new Set(prev);
      if (next.has(id)) next.delete(id);
      else next.add(id);
      return next;
    });
  };

  const pickMainImage = async (file: File | null) => {
    if (!file) return;
    setMainUploading(true);
    const url = await uploadCollectionImage(file);
    if (url) setMainImage(url);
    setMainUploading(false);
  };

  const pickEditMainImage = async (file: File | null) => {
    if (!file || !editingMain) return;
    setEditMainUploading(true);
    const url = await uploadCollectionImage(file);
    if (url) {
      if (editingMain.image) await deleteStorageImage(editingMain.image);
      setEditMainImage(url);
    }
    setEditMainUploading(false);
  };

  const pickSubImage = async (file: File | null) => {
    if (!file) return;
    setNewSubUploading(true);
    const url = await uploadCollectionImage(file);
    if (url) setNewSubImage(url);
    setNewSubUploading(false);
  };

  const pickEditSubImage = async (file: File | null) => {
    if (!file || !editingSub) return;
    setEditSubUploading(true);
    const url = await uploadCollectionImage(file);
    if (url) {
      if (editingSub.image) await deleteStorageImage(editingSub.image);
      setEditSubImage(url);
    }
    setEditSubUploading(false);
  };

  const addMainCategory = async () => {
    if (!mainName || !mainSlug) return;
    const { data, error } = await supabase
      .from('main_categories')
      .insert({
        name: mainName,
        slug: mainSlug,
        description: mainDesc || null,
        image: mainImage,
        display_order: mainCategories.length + 1,
      })
      .select()
      .single();
    if (!error && data) {
      setExpanded((prev) => new Set(prev).add(data.id));
    }
    setMainName('');
    setMainSlug('');
    setMainDesc('');
    setMainImage(null);
    setShowAddMain(false);
  };

  const deleteMainCategory = async (cat: MainCategory) => {
    if (!confirm(`Delete "${cat.name}" and all its sub-categories? Products will be unlinked.`)) return;
    if (cat.image) await deleteStorageImage(cat.image);
    await supabase.from('main_categories').delete().eq('id', cat.id);
    setEditingMain(null);
  };

  const startEditMain = (cat: MainCategory) => {
    setEditingMain(cat);
    setEditMainName(cat.name);
    setEditMainSlug(cat.slug);
    setEditMainDesc(cat.description ?? '');
    setEditMainImage(cat.image);
  };

  const saveEditMain = async () => {
    if (!editingMain || !editMainName || !editMainSlug) return;
    await supabase
      .from('main_categories')
      .update({
        name: editMainName,
        slug: editMainSlug,
        description: editMainDesc || null,
        image: editMainImage,
      })
      .eq('id', editingMain.id);
    setEditingMain(null);
  };

  const addSubcategory = async (mainId: string) => {
    if (!newSubName || !newSubSlug) return;
    await supabase.from('subcategories').insert({
      main_category_id: mainId,
      name: newSubName,
      slug: newSubSlug,
      image: newSubImage,
      display_order: subcategories.filter((s) => s.main_category_id === mainId).length + 1,
    });
    setNewSubName('');
    setNewSubSlug('');
    setNewSubImage(null);
    setShowAdd(null);
  };

  const deleteSubcategory = async (sub: Subcategory) => {
    if (!confirm('Delete this sub-category? Products in it will be unlinked.')) return;
    if (sub.image) await deleteStorageImage(sub.image);
    await supabase.from('subcategories').delete().eq('id', sub.id);
    setEditingSub(null);
  };

  const startEditSub = (sub: Subcategory) => {
    setEditingSub(sub);
    setEditSubName(sub.name);
    setEditSubSlug(sub.slug);
    setEditSubImage(sub.image);
  };

  const saveEditSub = async () => {
    if (!editingSub || !editSubName || !editSubSlug) return;
    await supabase
      .from('subcategories')
      .update({ name: editSubName, slug: editSubSlug, image: editSubImage })
      .eq('id', editingSub.id);
    setEditingSub(null);
  };

  const ImageThumb = ({ src, uploading }: { src: string | null; uploading: boolean }) => (
    <div className="relative h-24 w-20 overflow-hidden rounded-lg border border-ivory-300 bg-ivory-100">
      {src ? (
        <img src={src} alt="preview" className="h-full w-full object-cover" />
      ) : (
        <div className="flex h-full w-full items-center justify-center text-beige-400">
          <Upload size={18} />
        </div>
      )}
      {uploading && (
        <div className="absolute inset-0 flex items-center justify-center bg-white/60">
          <div className="h-5 w-5 animate-spin rounded-full border-2 border-champagne-400 border-t-transparent" />
        </div>
      )}
    </div>
  );

  return (
    <AdminLayout title="Collections">
      <p className="mb-6 text-sm text-charcoal-800/60">
        Create your own collections with images uploaded from your computer. They appear instantly on the public Collections page.
      </p>

      <button onClick={() => setShowAddMain((v) => !v)} className="btn-primary mb-6">
        <Plus size={16} /> Add New Collection
      </button>

      {showAddMain && (
        <div className="card-luxe mb-8 space-y-4 p-5">
          <h3 className="font-serif text-lg font-medium text-charcoal-900">New Collection</h3>
          <div className="grid gap-4 sm:grid-cols-2">
            <div>
              <label className="label-luxe">Collection Name</label>
              <input
                type="text"
                value={mainName}
                onChange={(e) => {
                  setMainName(e.target.value);
                  setMainSlug(slugify(e.target.value));
                }}
                className="input-luxe"
                placeholder="e.g. Festive Sarees"
              />
            </div>
            <div>
              <label className="label-luxe">Slug</label>
              <input
                type="text"
                value={mainSlug}
                onChange={(e) => setMainSlug(slugify(e.target.value))}
                className="input-luxe"
                placeholder="festive-sarees"
              />
            </div>
          </div>
          <div>
            <label className="label-luxe">Description (optional)</label>
            <textarea
              value={mainDesc}
              onChange={(e) => setMainDesc(e.target.value)}
              className="input-luxe min-h-[80px]"
              placeholder="Short description shown on the collection page"
            />
          </div>
          <div>
            <label className="label-luxe">Collection Image</label>
            <div className="flex items-center gap-4">
              <ImageThumb src={mainImage} uploading={mainUploading} />
              <div className="flex flex-col gap-2">
                <button
                  type="button"
                  onClick={() => mainFileRef.current?.click()}
                  className="btn-ghost w-fit"
                  disabled={mainUploading}
                >
                  <Upload size={16} /> Upload from computer
                </button>
                {mainImage && (
                  <button
                    type="button"
                    onClick={() => setMainImage(null)}
                    className="text-xs text-red-600 hover:underline w-fit"
                  >
                    Remove image
                  </button>
                )}
              </div>
              <input
                ref={mainFileRef}
                type="file"
                accept="image/*"
                className="hidden"
                onChange={(e) => pickMainImage(e.target.files?.[0] ?? null)}
              />
            </div>
          </div>
          <div className="flex gap-2">
            <button onClick={addMainCategory} className="btn-primary">
              <Plus size={16} /> Create Collection
            </button>
            <button onClick={() => setShowAddMain(false)} className="btn-ghost">
              Cancel
            </button>
          </div>
        </div>
      )}

      {loading ? (
        <div className="space-y-3">
          {[...Array(4)].map((_, i) => (
            <div key={i} className="skeleton h-16 rounded-xl" />
          ))}
        </div>
      ) : (
        <div className="space-y-3">
          {mainCategories.map((cat) => {
            const subs = subcategories.filter((s) => s.main_category_id === cat.id);
            const isOpen = expanded.has(cat.id);
            return (
              <div key={cat.id} className="card-luxe overflow-hidden">
                <div className="flex items-center justify-between p-5">
                  <button onClick={() => toggle(cat.id)} className="flex flex-1 items-center gap-3 text-left">
                    {isOpen ? <ChevronDown size={18} /> : <ChevronRight size={18} />}
                    <div className="h-12 w-10 shrink-0 overflow-hidden rounded-lg bg-ivory-100">
                      {cat.image ? (
                        <img src={cat.image} alt={cat.name} className="h-full w-full object-cover" />
                      ) : (
                        <div className="flex h-full w-full items-center justify-center text-beige-400 text-xs">
                          N/A
                        </div>
                      )}
                    </div>
                    <div>
                      <span className="block font-serif text-lg font-medium text-charcoal-900">{cat.name}</span>
                      <span className="text-xs text-beige-500">/{cat.slug} · {subs.length} sub-categories</span>
                    </div>
                  </button>
                  <div className="flex items-center gap-1">
                    <button
                      onClick={() => startEditMain(cat)}
                      className="rounded-lg p-2 text-charcoal-800/60 transition-colors hover:bg-ivory-100 hover:text-charcoal-900"
                      title="Edit collection"
                    >
                      <Edit2 size={15} />
                    </button>
                    <button
                      onClick={() => deleteMainCategory(cat)}
                      className="rounded-lg p-2 text-charcoal-800/60 transition-colors hover:bg-red-50 hover:text-red-600"
                      title="Delete collection"
                    >
                      <Trash2 size={15} />
                    </button>
                  </div>
                </div>

                {isOpen && (
                  <div className="border-t border-ivory-100 px-5 py-4">
                    <div className="space-y-2">
                      {subs.map((sub) => (
                        <div
                          key={sub.id}
                          className="flex items-center justify-between rounded-lg bg-ivory-50 px-4 py-2.5"
                        >
                          <div className="flex items-center gap-3">
                            <div className="h-10 w-8 shrink-0 overflow-hidden rounded bg-ivory-200">
                              {sub.image ? (
                                <img src={sub.image} alt={sub.name} className="h-full w-full object-cover" />
                              ) : null}
                            </div>
                            <div>
                              <span className="text-sm font-medium text-charcoal-900">{sub.name}</span>
                              <span className="ml-2 text-xs text-beige-500">/{sub.slug}</span>
                            </div>
                          </div>
                          <div className="flex items-center gap-1">
                            <button
                              onClick={() => startEditSub(sub)}
                              className="rounded-lg p-1.5 text-charcoal-800/60 transition-colors hover:bg-ivory-100 hover:text-charcoal-900"
                            >
                              <Edit2 size={14} />
                            </button>
                            <button
                              onClick={() => deleteSubcategory(sub)}
                              className="rounded-lg p-1.5 text-charcoal-800/60 transition-colors hover:bg-red-50 hover:text-red-600"
                            >
                              <Trash2 size={15} />
                            </button>
                          </div>
                        </div>
                      ))}
                      {subs.length === 0 && (
                        <p className="py-2 text-sm text-beige-400">No sub-categories yet.</p>
                      )}
                    </div>

                    {showAdd === cat.id ? (
                      <div className="mt-3 space-y-3 rounded-lg bg-champagne-50 p-3">
                        <div className="flex flex-col gap-2 sm:flex-row">
                          <input
                            type="text"
                            placeholder="Sub-category name"
                            value={newSubName}
                            onChange={(e) => {
                              setNewSubName(e.target.value);
                              setNewSubSlug(slugify(e.target.value));
                            }}
                            className="input-luxe flex-1"
                          />
                          <input
                            type="text"
                            placeholder="slug"
                            value={newSubSlug}
                            onChange={(e) => setNewSubSlug(e.target.value)}
                            className="input-luxe flex-1"
                          />
                        </div>
                        <div className="flex items-center gap-3">
                          <ImageThumb src={newSubImage} uploading={newSubUploading} />
                          <button
                            type="button"
                            onClick={() => subFileRef.current?.click()}
                            className="btn-ghost w-fit"
                            disabled={newSubUploading}
                          >
                            <Upload size={16} /> Upload image
                          </button>
                          {newSubImage && (
                            <button
                              type="button"
                              onClick={() => setNewSubImage(null)}
                              className="text-xs text-red-600 hover:underline"
                            >
                              Remove
                            </button>
                          )}
                          <input
                            ref={subFileRef}
                            type="file"
                            accept="image/*"
                            className="hidden"
                            onChange={(e) => pickSubImage(e.target.files?.[0] ?? null)}
                          />
                        </div>
                        <div className="flex gap-2">
                          <button onClick={() => addSubcategory(cat.id)} className="btn-primary whitespace-nowrap">
                            <Plus size={16} /> Add
                          </button>
                          <button onClick={() => setShowAdd(null)} className="btn-ghost">
                            Cancel
                          </button>
                        </div>
                      </div>
                    ) : (
                      <button
                        onClick={() => {
                          setShowAdd(cat.id);
                          setNewSubName('');
                          setNewSubSlug('');
                          setNewSubImage(null);
                        }}
                        className="mt-3 inline-flex items-center gap-1.5 text-sm font-medium text-champagne-500 hover:text-champagne-600"
                      >
                        <Plus size={16} /> Add Sub-category
                      </button>
                    )}
                  </div>
                )}
              </div>
            );
          })}
        </div>
      )}

      {/* Edit Main Category Modal */}
      {editingMain && (
        <div className="fixed inset-0 z-50 flex items-center justify-center bg-charcoal-900/40 p-4">
          <div className="card-luxe w-full max-w-lg space-y-4 p-6">
            <div className="flex items-center justify-between">
              <h3 className="font-serif text-lg font-medium text-charcoal-900">Edit Collection</h3>
              <button onClick={() => setEditingMain(null)} className="rounded-lg p-1 hover:bg-ivory-100">
                <X size={18} />
              </button>
            </div>
            <div className="grid gap-4 sm:grid-cols-2">
              <div>
                <label className="label-luxe">Name</label>
                <input
                  type="text"
                  value={editMainName}
                  onChange={(e) => setEditMainName(e.target.value)}
                  className="input-luxe"
                />
              </div>
              <div>
                <label className="label-luxe">Slug</label>
                <input
                  type="text"
                  value={editMainSlug}
                  onChange={(e) => setEditMainSlug(slugify(e.target.value))}
                  className="input-luxe"
                />
              </div>
            </div>
            <div>
              <label className="label-luxe">Description</label>
              <textarea
                value={editMainDesc}
                onChange={(e) => setEditMainDesc(e.target.value)}
                className="input-luxe min-h-[70px]"
              />
            </div>
            <div>
              <label className="label-luxe">Image</label>
              <div className="flex items-center gap-4">
                <ImageThumb src={editMainImage} uploading={editMainUploading} />
                <div className="flex flex-col gap-2">
                  <button
                    type="button"
                    onClick={() => editMainFileRef.current?.click()}
                    className="btn-ghost w-fit"
                    disabled={editMainUploading}
                  >
                    <Upload size={16} /> Upload new image
                  </button>
                  {editMainImage && (
                    <button
                      type="button"
                      onClick={() => setEditMainImage(null)}
                      className="text-xs text-red-600 hover:underline w-fit"
                    >
                      Remove image
                    </button>
                  )}
                </div>
                <input
                  ref={editMainFileRef}
                  type="file"
                  accept="image/*"
                  className="hidden"
                  onChange={(e) => pickEditMainImage(e.target.files?.[0] ?? null)}
                />
              </div>
            </div>
            <div className="flex justify-end gap-2">
              <button onClick={() => setEditingMain(null)} className="btn-ghost">
                Cancel
              </button>
              <button onClick={saveEditMain} className="btn-primary">
                Save Changes
              </button>
            </div>
          </div>
        </div>
      )}

      {/* Edit Sub-category Modal */}
      {editingSub && (
        <div className="fixed inset-0 z-50 flex items-center justify-center bg-charcoal-900/40 p-4">
          <div className="card-luxe w-full max-w-lg space-y-4 p-6">
            <div className="flex items-center justify-between">
              <h3 className="font-serif text-lg font-medium text-charcoal-900">Edit Sub-category</h3>
              <button onClick={() => setEditingSub(null)} className="rounded-lg p-1 hover:bg-ivory-100">
                <X size={18} />
              </button>
            </div>
            <div className="grid gap-4 sm:grid-cols-2">
              <div>
                <label className="label-luxe">Name</label>
                <input
                  type="text"
                  value={editSubName}
                  onChange={(e) => setEditSubName(e.target.value)}
                  className="input-luxe"
                />
              </div>
              <div>
                <label className="label-luxe">Slug</label>
                <input
                  type="text"
                  value={editSubSlug}
                  onChange={(e) => setEditSubSlug(slugify(e.target.value))}
                  className="input-luxe"
                />
              </div>
            </div>
            <div>
              <label className="label-luxe">Image</label>
              <div className="flex items-center gap-4">
                <ImageThumb src={editSubImage} uploading={editSubUploading} />
                <div className="flex flex-col gap-2">
                  <button
                    type="button"
                    onClick={() => editSubFileRef.current?.click()}
                    className="btn-ghost w-fit"
                    disabled={editSubUploading}
                  >
                    <Upload size={16} /> Upload new image
                  </button>
                  {editSubImage && (
                    <button
                      type="button"
                      onClick={() => setEditSubImage(null)}
                      className="text-xs text-red-600 hover:underline w-fit"
                    >
                      Remove image
                    </button>
                  )}
                </div>
                <input
                  ref={editSubFileRef}
                  type="file"
                  accept="image/*"
                  className="hidden"
                  onChange={(e) => pickEditSubImage(e.target.files?.[0] ?? null)}
                />
              </div>
            </div>
            <div className="flex justify-end gap-2">
              <button onClick={() => setEditingSub(null)} className="btn-ghost">
                Cancel
              </button>
              <button onClick={saveEditSub} className="btn-primary">
                Save Changes
              </button>
            </div>
          </div>
        </div>
      )}
    </AdminLayout>
  );
}
