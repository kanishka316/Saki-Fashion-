import { useState } from 'react';
import { Search } from 'lucide-react';
import AdminLayout from '../../components/admin/AdminLayout';
import { useProducts } from '../../lib/useProducts';
import { supabase, type Product } from '../../lib/supabase';

const availabilityOptions: Product['availability'][] = ['In Stock', 'Limited Stock', 'Out of Stock'];

const styles: Record<string, string> = {
  'In Stock': 'bg-green-100 text-green-700',
  'Limited Stock': 'bg-champagne-200 text-champagne-700',
  'Out of Stock': 'bg-red-100 text-red-600',
};

export default function AdminStock() {
  const [search, setSearch] = useState('');
  const { products, loading } = useProducts({ search });
  const [updating, setUpdating] = useState<string | null>(null);

  const updateAvailability = async (id: string, availability: Product['availability']) => {
    setUpdating(id);
    await supabase.from('products').update({ availability }).eq('id', id);
    setUpdating(null);
  };

  return (
    <AdminLayout title="Stock Management">
      <div className="mb-6 relative max-w-xs">
        <Search size={18} className="absolute left-3 top-1/2 -translate-y-1/2 text-beige-400" />
        <input
          type="text"
          placeholder="Search products..."
          value={search}
          onChange={(e) => setSearch(e.target.value)}
          className="input-luxe pl-10"
        />
      </div>

      {loading ? (
        <div className="space-y-3">
          {[...Array(5)].map((_, i) => (
            <div key={i} className="skeleton h-16 rounded-xl" />
          ))}
        </div>
      ) : products.length === 0 ? (
        <p className="rounded-xl bg-ivory-100 p-12 text-center text-charcoal-800/60">
          No products found.
        </p>
      ) : (
        <div className="space-y-2">
          {products.map((p) => (
            <div
              key={p.id}
              className="card-luxe flex flex-col gap-3 p-4 sm:flex-row sm:items-center sm:justify-between"
            >
              <div className="flex items-center gap-3">
                <div className="h-12 w-10 shrink-0 overflow-hidden rounded-lg bg-ivory-100">
                  {p.images[0] && <img src={p.images[0]} alt={p.name} className="h-full w-full object-cover" />}
                </div>
                <div>
                  <p className="font-medium text-charcoal-900">{p.name}</p>
                  <p className="text-xs text-beige-500">{p.product_code}</p>
                </div>
              </div>
              <div className="flex items-center gap-3">
                <span className={`rounded-full px-3 py-1 text-xs ${styles[p.availability]}`}>
                  {p.availability}
                </span>
                <select
                  value={p.availability}
                  disabled={updating === p.id}
                  onChange={(e) => updateAvailability(p.id, e.target.value as Product['availability'])}
                  className="input-luxe w-auto py-2 text-sm"
                >
                  {availabilityOptions.map((opt) => (
                    <option key={opt} value={opt}>{opt}</option>
                  ))}
                </select>
              </div>
            </div>
          ))}
        </div>
      )}
    </AdminLayout>
  );
}
