import { Link } from 'react-router-dom';
import { ArrowRight, Sparkles, Truck, Heart, Gem } from 'lucide-react';
import HeroSlider from '../components/HeroSlider';
import Reveal from '../components/Reveal';
import ProductCard from '../components/ProductCard';
import { useCategories } from '../lib/useCategories';
import { useProducts } from '../lib/useProducts';
import { useGalleryImages } from '../lib/useGallery';
import { CONTACT } from '../lib/constants';

const collectionImages: Record<string, string> = {
  sarees: 'https://images.pexels.com/photos/8489763/pexels-photo-8489763.jpeg?auto=compress&cs=tinysrgb&w=800',
  'dress-materials': 'https://images.pexels.com/photos/8886949/pexels-photo-8886949.jpeg?auto=compress&cs=tinysrgb&w=800',
  'new-arrivals': 'https://images.pexels.com/photos/36430688/pexels-photo-36430688.jpeg?auto=compress&cs=tinysrgb&w=800',
};

const whyChooseUs = [
  { icon: Gem, title: 'Premium Quality', desc: 'Handpicked fabrics and finishes that speak of true craftsmanship.' },
  { icon: Sparkles, title: 'Latest Collections', desc: 'Freshly curated styles arriving every season.' },
  { icon: Heart, title: 'Affordable Boutique Fashion', desc: 'Luxury feel at boutique-friendly prices.' },
  { icon: Truck, title: 'Friendly Service', desc: 'Personalised guidance to find your perfect look.' },
];

const reviews = [
  { name: 'Priya Subramanian', text: 'Saki has the most beautiful silk sarees in Tirupur. The quality and colours are stunning!', role: 'Bride-to-be' },
  { name: 'Lakshmi Nair', text: 'I found the perfect silk saree for my sister\'s wedding. Elegant designs and lovely service.', role: 'Regular Customer' },
  { name: 'Divya Krishnan', text: 'Their dress materials are my go-to for everyday elegance. Premium feel without the premium price.', role: 'Working Professional' },
];

export default function Home() {
  const { mainCategories } = useCategories();
  const { products } = useProducts({ newArrivalsOnly: true });
  const { images: galleryImages } = useGalleryImages();

  const featured = products.slice(0, 4);
  const galleryPreview = galleryImages.slice(0, 6);

  return (
    <div>
      <HeroSlider />

      {/* About teaser */}
      <section className="container-luxe py-24">
        <div className="grid items-center gap-12 md:grid-cols-2">
          <Reveal>
            <div className="relative">
              <div className="overflow-hidden rounded-3xl shadow-luxe">
                <img
                  src="https://images.pexels.com/photos/29105327/pexels-photo-29105327.jpeg?auto=compress&cs=tinysrgb&w=800"
                  alt="Saki Boutique"
                  className="h-[480px] w-full object-cover image-zoom"
                />
              </div>
              <div className="absolute -bottom-6 -right-6 hidden rounded-2xl bg-champagne-400 px-8 py-6 text-center shadow-luxe sm:block">
                <p className="font-serif text-3xl font-semibold text-charcoal-900">Est.</p>
                <p className="text-xs uppercase tracking-[0.2em] text-charcoal-800">Tirupur</p>
              </div>
            </div>
          </Reveal>
          <Reveal delay={150}>
            <p className="section-eyebrow">Welcome to Saki</p>
            <h2 className="mt-3 text-4xl font-medium text-charcoal-900 md:text-5xl">
              A Fashion Destination for the Modern Woman
            </h2>
            <p className="mt-6 text-base leading-relaxed text-charcoal-800/80">
              At Saki, we believe every woman deserves to feel elegant. Our boutique brings you a
              carefully curated collection of sarees and dress materials — each piece selected for
              piece selected for its fabric, craftsmanship and timeless appeal.
            </p>
            <p className="mt-4 text-base leading-relaxed text-charcoal-800/80">
              From everyday grace to bridal grandeur, we help you find the perfect ensemble for
              every moment that matters.
            </p>
            <Link to="/about" className="btn-outline mt-8">
              Our Story <ArrowRight size={16} />
            </Link>
          </Reveal>
        </div>
      </section>

      {/* Luxury editorial banner */}
      <section className="relative overflow-hidden">
        <div className="relative h-[420px] w-full overflow-hidden">
          <img
            src="https://images.pexels.com/photos/28517491/pexels-photo-28517491.jpeg?auto=compress&cs=tinysrgb&w=1600"
            alt="Elegant saree portrait"
            className="h-full w-full object-cover"
          />
          <div className="absolute inset-0 bg-gradient-to-r from-charcoal-900/60 via-charcoal-900/30 to-transparent" />
          <div className="absolute inset-0 flex items-center">
            <div className="container-luxe">
              <Reveal>
                <p className="text-xs font-medium uppercase tracking-[0.4em] text-champagne-200">The Saki Promise</p>
                <h2 className="mt-4 max-w-lg text-balance text-3xl font-medium leading-tight text-ivory-50 drop-shadow-lg sm:text-4xl md:text-5xl">
                  Where Tradition Meets Timeless Elegance
                </h2>
                <p className="mt-4 max-w-md text-sm leading-relaxed text-ivory-100/85">
                  Every drape, every weave, every silhouette — crafted to celebrate the woman within.
                </p>
              </Reveal>
            </div>
          </div>
        </div>
      </section>

      {/* Collections */}
      <section className="bg-ivory-100 py-24">
        <div className="container-luxe">
          <Reveal>
            <div className="text-center">
              <p className="section-eyebrow">Explore</p>
              <h2 className="mt-3 text-4xl font-medium text-charcoal-900 md:text-5xl">
                Our Collections
              </h2>
              <p className="mx-auto mt-4 max-w-lg text-charcoal-800/70">
                Five distinct collections, each crafted to celebrate a different facet of femininity.
              </p>
            </div>
          </Reveal>

          <div className="mt-14 grid gap-6 sm:grid-cols-2 lg:grid-cols-3">
            {mainCategories
              .filter((c) => c.slug !== 'new-arrivals')
              .map((cat, i) => (
                <Reveal key={cat.id} delay={i * 100}>
                  <Link
                    to={`/collections/${cat.slug}`}
                    className="group relative block h-80 overflow-hidden rounded-2xl shadow-soft hover:shadow-luxe"
                  >
                    <img
                      src={collectionImages[cat.slug] ?? 'https://images.pexels.com/photos/8886949/pexels-photo-8886949.jpeg?auto=compress&cs=tinysrgb&w=800'}
                      alt={cat.name}
                      className="h-full w-full object-cover image-zoom"
                    />
                    <div className="absolute inset-0 bg-gradient-to-t from-charcoal-900/70 via-charcoal-900/20 to-transparent" />
                    <div className="absolute inset-x-0 bottom-0 p-6">
                      <h3 className="font-serif text-2xl font-medium text-ivory-50">{cat.name}</h3>
                      <p className="mt-1 text-sm text-ivory-100/80">{cat.description}</p>
                      <span className="mt-3 inline-flex items-center gap-1.5 text-xs font-medium uppercase tracking-[0.15em] text-champagne-200 transition-colors group-hover:text-champagne-100">
                        View Collection <ArrowRight size={14} />
                      </span>
                    </div>
                  </Link>
                </Reveal>
              ))}

            {/* New Arrivals feature card */}
            <Reveal delay={300}>
              <Link
                to="/collections/new-arrivals"
                className="group relative flex h-80 flex-col items-center justify-center overflow-hidden rounded-2xl bg-charcoal-900 shadow-soft hover:shadow-luxe"
              >
                <Sparkles className="mb-3 text-champagne-300" size={32} />
                <h3 className="font-serif text-2xl font-medium text-ivory-50">New Arrivals</h3>
                <p className="mt-1 px-6 text-center text-sm text-ivory-100/70">
                  The latest additions to our boutique
                </p>
                <span className="mt-3 inline-flex items-center gap-1.5 text-xs font-medium uppercase tracking-[0.15em] text-champagne-300 transition-colors group-hover:text-champagne-100">
                  Explore Now <ArrowRight size={14} />
                </span>
              </Link>
            </Reveal>
          </div>
        </div>
      </section>

      {/* New Arrivals featured products */}
      {featured.length > 0 && (
        <section className="container-luxe py-24">
          <Reveal>
            <div className="flex flex-col items-center justify-between gap-4 sm:flex-row">
              <div>
                <p className="section-eyebrow">Just In</p>
                <h2 className="mt-2 text-4xl font-medium text-charcoal-900 md:text-5xl">
                  New Arrivals
                </h2>
              </div>
              <Link to="/collections/new-arrivals" className="btn-ghost">
                View All <ArrowRight size={16} />
              </Link>
            </div>
          </Reveal>
          <div className="mt-12 grid gap-6 sm:grid-cols-2 lg:grid-cols-4">
            {featured.map((p, i) => (
              <Reveal key={p.id} delay={i * 100}>
                <ProductCard product={p} />
              </Reveal>
            ))}
          </div>
        </section>
      )}

      {/* Craftsmanship showcase */}
      <section className="container-luxe py-24">
        <Reveal>
          <div className="text-center">
            <p className="section-eyebrow">Craftsmanship</p>
            <h2 className="mt-3 text-4xl font-medium text-charcoal-900 md:text-5xl">
              The Art Behind Every Piece
            </h2>
            <p className="mx-auto mt-4 max-w-lg text-charcoal-800/70">
              From handwoven silks to intricately printed cottons, each piece in our collection is a testament to artisanal skill.
            </p>
          </div>
        </Reveal>
        <div className="mt-14 grid gap-4 md:grid-cols-4">
          <Reveal>
            <div className="group relative h-72 overflow-hidden rounded-2xl shadow-soft hover:shadow-luxe">
              <img
                src="https://images.pexels.com/photos/8886952/pexels-photo-8886952.jpeg?auto=compress&cs=tinysrgb&w=600"
                alt="Fine fabrics"
                className="h-full w-full object-cover image-zoom"
              />
              <div className="absolute inset-0 bg-gradient-to-t from-charcoal-900/50 to-transparent" />
              <p className="absolute bottom-4 left-4 font-serif text-lg text-ivory-50">Fine Fabrics</p>
            </div>
          </Reveal>
          <Reveal delay={100}>
            <div className="group relative h-72 overflow-hidden rounded-2xl shadow-soft hover:shadow-luxe">
              <img
                src="https://images.pexels.com/photos/29819599/pexels-photo-29819599.jpeg?auto=compress&cs=tinysrgb&w=600"
                alt="Elegant drapes"
                className="h-full w-full object-cover image-zoom"
              />
              <div className="absolute inset-0 bg-gradient-to-t from-charcoal-900/50 to-transparent" />
              <p className="absolute bottom-4 left-4 font-serif text-lg text-ivory-50">Elegant Drapes</p>
            </div>
          </Reveal>
          <Reveal delay={200}>
            <div className="group relative h-72 overflow-hidden rounded-2xl shadow-soft hover:shadow-luxe">
              <img
                src="https://images.pexels.com/photos/32161001/pexels-photo-32161001.jpeg?auto=compress&cs=tinysrgb&w=600"
                alt="Festive couture"
                className="h-full w-full object-cover image-zoom"
              />
              <div className="absolute inset-0 bg-gradient-to-t from-charcoal-900/50 to-transparent" />
              <p className="absolute bottom-4 left-4 font-serif text-lg text-ivory-50">Festive Couture</p>
            </div>
          </Reveal>
          <Reveal delay={300}>
            <div className="group relative h-72 overflow-hidden rounded-2xl shadow-soft hover:shadow-luxe">
              <img
                src="https://images.pexels.com/photos/18010643/pexels-photo-18010643.jpeg?auto=compress&cs=tinysrgb&w=600"
                alt="Bridal heritage"
                className="h-full w-full object-cover image-zoom"
              />
              <div className="absolute inset-0 bg-gradient-to-t from-charcoal-900/50 to-transparent" />
              <p className="absolute bottom-4 left-4 font-serif text-lg text-ivory-50">Bridal Heritage</p>
            </div>
          </Reveal>
        </div>
      </section>

      {/* Why Choose Us */}
      <section className="bg-ivory-100 py-24">
        <div className="container-luxe">
          <Reveal>
            <div className="text-center">
              <p className="section-eyebrow">Why Saki</p>
              <h2 className="mt-3 text-4xl font-medium text-charcoal-900 md:text-5xl">
                The Saki Experience
              </h2>
            </div>
          </Reveal>
          <div className="mt-14 grid gap-6 sm:grid-cols-2 lg:grid-cols-4">
            {whyChooseUs.map((item, i) => (
              <Reveal key={item.title} delay={i * 100}>
                <div className="card-luxe hover-luxe p-8 text-center hover:shadow-luxe">
                  <div className="mx-auto flex h-14 w-14 items-center justify-center rounded-full bg-champagne-100 text-champagne-500">
                    <item.icon size={24} />
                  </div>
                  <h3 className="mt-5 font-serif text-xl font-medium text-charcoal-900">{item.title}</h3>
                  <p className="mt-2 text-sm leading-relaxed text-charcoal-800/70">{item.desc}</p>
                </div>
              </Reveal>
            ))}
          </div>
        </div>
      </section>

      {/* Gallery preview */}
      {galleryPreview.length > 0 && (
        <section className="container-luxe py-24">
          <Reveal>
            <div className="text-center">
              <p className="section-eyebrow">Gallery</p>
              <h2 className="mt-3 text-4xl font-medium text-charcoal-900 md:text-5xl">
                Moments at Saki
              </h2>
            </div>
          </Reveal>
          <div className="mt-12 grid grid-cols-2 gap-4 md:grid-cols-3">
            {galleryPreview.map((img, i) => (
              <Reveal key={img.id} delay={i * 80}>
                <div
                  className={`overflow-hidden rounded-xl shadow-soft ${
                    i % 3 === 1 ? 'md:row-span-2 md:h-full' : ''
                  }`}
                >
                  <img
                    src={img.url}
                    alt={img.label ?? 'Gallery'}
                    loading="lazy"
                    className={`w-full object-cover image-zoom ${
                      i % 3 === 1 ? 'h-64 md:h-full' : 'h-48'
                    }`}
                  />
                </div>
              </Reveal>
            ))}
          </div>
          <div className="mt-10 text-center">
            <Link to="/gallery" className="btn-outline">
              View Full Gallery <ArrowRight size={16} />
            </Link>
          </div>
        </section>
      )}

      {/* Reviews */}
      <section className="bg-charcoal-900 py-24 text-ivory-100">
        <div className="container-luxe">
          <Reveal>
            <div className="text-center">
              <p className="text-xs font-medium uppercase tracking-[0.3em] text-champagne-300">
                Testimonials
              </p>
              <h2 className="mt-3 text-4xl font-medium text-ivory-50 md:text-5xl">
                Loved by Our Customers
              </h2>
            </div>
          </Reveal>
          <div className="mt-14 grid gap-6 md:grid-cols-3">
            {reviews.map((r, i) => (
              <Reveal key={r.name} delay={i * 120}>
                <div className="rounded-2xl bg-charcoal-800 p-8 shadow-luxe">
                  <div className="mb-4 flex gap-1 text-champagne-300">
                    {'★★★★★'.split('').map((s, j) => (
                      <span key={j}>{s}</span>
                    ))}
                  </div>
                  <p className="text-base leading-relaxed text-ivory-100/90">"{r.text}"</p>
                  <div className="mt-6">
                    <p className="font-serif text-lg text-ivory-50">{r.name}</p>
                    <p className="text-xs uppercase tracking-[0.12em] text-champagne-300">{r.role}</p>
                  </div>
                </div>
              </Reveal>
            ))}
          </div>
        </div>
      </section>

      {/* Contact CTA */}
      <section className="container-luxe py-24">
        <Reveal>
          <div className="rounded-3xl bg-gradient-to-br from-champagne-100 to-ivory-200 p-12 text-center shadow-luxe md:p-16">
            <h2 className="text-4xl font-medium text-charcoal-900 md:text-5xl">
              Visit Our Boutique
            </h2>
            <p className="mx-auto mt-4 max-w-lg text-charcoal-800/70">
              {CONTACT.address.line1}, {CONTACT.address.line2}, {CONTACT.address.city},{' '}
              {CONTACT.address.state} - {CONTACT.address.pincode}
            </p>
            <div className="mt-8 flex flex-col items-center justify-center gap-3 sm:flex-row">
              <a href={`tel:${CONTACT.phoneRaw}`} className="btn-primary">
                Call Us
              </a>
              <a
                href={`https://wa.me/${CONTACT.whatsapp}`}
                target="_blank"
                rel="noreferrer"
                className="btn-outline"
              >
                WhatsApp
              </a>
            </div>
          </div>
        </Reveal>
      </section>
    </div>
  );
}
