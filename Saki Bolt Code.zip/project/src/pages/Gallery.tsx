import Reveal from '../components/Reveal';
import { useGalleryImages } from '../lib/useGallery';

export default function Gallery() {
  const { images, loading } = useGalleryImages();

  const heights = ['h-64', 'h-80', 'h-72', 'h-96', 'h-64', 'h-80', 'h-72', 'h-96'];

  return (
    <div className="pt-28">
      <div className="container-luxe py-12 text-center">
        <Reveal>
          <p className="section-eyebrow">Visual Diary</p>
          <h1 className="mt-3 text-5xl font-medium text-charcoal-900 md:text-6xl">Gallery</h1>
          <p className="mx-auto mt-4 max-w-lg text-charcoal-800/70">
            A glimpse into the world of Saki — premium boutique photography of our finest pieces.
          </p>
        </Reveal>
      </div>

      <div className="container-luxe pb-24">
        {loading ? (
          <div className="columns-1 gap-4 sm:columns-2 lg:columns-3 [&>*]:mb-4">
            {[...Array(6)].map((_, i) => (
              <div key={i} className={`skeleton ${heights[i % heights.length]} w-full rounded-xl`} />
            ))}
          </div>
        ) : images.length === 0 ? (
          <p className="py-16 text-center text-charcoal-800/60">
            Gallery is being curated. Check back soon.
          </p>
        ) : (
          <div className="columns-1 gap-4 sm:columns-2 lg:columns-3 [&>*]:mb-4">
            {images.map((img, i) => (
              <Reveal key={img.id} delay={(i % 6) * 80}>
                <div className="group relative overflow-hidden rounded-xl shadow-soft hover:shadow-luxe">
                  <img
                    src={img.url}
                    alt={img.label ?? `Gallery ${i + 1}`}
                    loading="lazy"
                    className={`w-full object-cover image-zoom ${heights[i % heights.length]}`}
                  />
                  {img.label && (
                    <div className="absolute inset-0 flex items-end bg-gradient-to-t from-charcoal-900/50 to-transparent opacity-0 transition-opacity duration-300 group-hover:opacity-100">
                      <p className="p-4 text-sm text-ivory-50">{img.label}</p>
                    </div>
                  )}
                </div>
              </Reveal>
            ))}
          </div>
        )}
      </div>
    </div>
  );
}
