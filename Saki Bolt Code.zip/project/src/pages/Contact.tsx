import { Phone, MessageCircle, Instagram, MapPin, Navigation } from 'lucide-react';
import Reveal from '../components/Reveal';
import { CONTACT } from '../lib/constants';

export default function Contact() {
  return (
    <div className="pt-28">
      <div className="container-luxe py-12 text-center">
        <Reveal>
          <p className="section-eyebrow">Get in Touch</p>
          <h1 className="mt-3 text-5xl font-medium text-charcoal-900 md:text-6xl">Visit Our Boutique</h1>
          <p className="mx-auto mt-4 max-w-lg text-charcoal-800/70">
            We'd love to welcome you. Reach out or drop by to explore our collections in person.
          </p>
        </Reveal>
      </div>

      <div className="container-luxe pb-24">
        <div className="grid gap-8 lg:grid-cols-2">
          {/* Contact cards */}
          <div className="space-y-4">
            <Reveal>
              <a
                href={`tel:${CONTACT.phoneRaw}`}
                className="card-luxe hover-luxe flex items-center gap-5 p-6 hover:shadow-luxe"
              >
                <div className="flex h-14 w-14 items-center justify-center rounded-full bg-champagne-100 text-champagne-500">
                  <Phone size={24} />
                </div>
                <div>
                  <h3 className="font-serif text-xl font-medium text-charcoal-900">Call Us</h3>
                  <p className="text-sm text-charcoal-800/70">{CONTACT.phone}</p>
                </div>
              </a>
            </Reveal>

            <Reveal delay={80}>
              <a
                href={`https://wa.me/${CONTACT.whatsapp}`}
                target="_blank"
                rel="noreferrer"
                className="card-luxe hover-luxe flex items-center gap-5 p-6 hover:shadow-luxe"
              >
                <div className="flex h-14 w-14 items-center justify-center rounded-full bg-green-100 text-green-600">
                  <MessageCircle size={24} />
                </div>
                <div>
                  <h3 className="font-serif text-xl font-medium text-charcoal-900">WhatsApp</h3>
                  <p className="text-sm text-charcoal-800/70">Chat with us directly</p>
                </div>
              </a>
            </Reveal>

            <Reveal delay={160}>
              <a
                href={CONTACT.instagram}
                target="_blank"
                rel="noreferrer"
                className="card-luxe hover-luxe flex items-center gap-5 p-6 hover:shadow-luxe"
              >
                <div className="flex h-14 w-14 items-center justify-center rounded-full bg-pink-100 text-pink-600">
                  <Instagram size={24} />
                </div>
                <div>
                  <h3 className="font-serif text-xl font-medium text-charcoal-900">Instagram</h3>
                  <p className="text-sm text-charcoal-800/70">@{CONTACT.instagramHandle}</p>
                </div>
              </a>
            </Reveal>

            <Reveal delay={240}>
              <div className="card-luxe p-6">
                <div className="flex items-start gap-4">
                  <div className="flex h-14 w-14 shrink-0 items-center justify-center rounded-full bg-champagne-100 text-champagne-500">
                    <MapPin size={24} />
                  </div>
                  <div>
                    <h3 className="font-serif text-xl font-medium text-charcoal-900">Our Address</h3>
                    <address className="mt-1 text-sm not-italic leading-relaxed text-charcoal-800/70">
                      {CONTACT.address.line1},
                      <br />
                      {CONTACT.address.line2},
                      <br />
                      {CONTACT.address.line3},
                      <br />
                      {CONTACT.address.city}, {CONTACT.address.state} - {CONTACT.address.pincode}
                    </address>
                    <a
                      href={CONTACT.mapsLink}
                      target="_blank"
                      rel="noreferrer"
                      className="mt-3 inline-flex items-center gap-2 rounded-full bg-charcoal-900 px-5 py-2.5 text-xs font-medium uppercase tracking-[0.12em] text-ivory-50 transition-all hover:bg-champagne-500 hover:text-charcoal-900"
                    >
                      <Navigation size={14} /> Get Directions
                    </a>
                  </div>
                </div>
              </div>
            </Reveal>
          </div>

          {/* Luxury image instead of map */}
          <Reveal delay={120}>
            <div className="relative h-full min-h-[500px] overflow-hidden rounded-2xl shadow-luxe">
              <img
                src="https://images.pexels.com/photos/32346245/pexels-photo-32346245.jpeg?auto=compress&cs=tinysrgb&w=900"
                alt="Saki Boutique — elegant traditional Indian attire"
                className="h-full w-full object-cover image-zoom"
              />
              <div className="absolute inset-0 bg-gradient-to-t from-charcoal-900/50 via-transparent to-transparent" />
              <div className="absolute bottom-0 left-0 p-8">
                <p className="font-serif text-2xl font-medium text-ivory-50">Saki</p>
                <p className="text-xs uppercase tracking-[0.2em] text-champagne-200">A Fashion Destination</p>
              </div>
            </div>
          </Reveal>
        </div>

        {/* Quick actions bar */}
        <Reveal>
          <div className="mt-8 flex flex-col items-center justify-center gap-3 rounded-2xl bg-charcoal-900 p-6 sm:flex-row">
            <p className="text-sm text-ivory-100/80">Have a question? We're here to help.</p>
            <div className="flex gap-3">
              <a href={`tel:${CONTACT.phoneRaw}`} className="btn-primary">
                <Phone size={15} /> Call
              </a>
              <a
                href={`https://wa.me/${CONTACT.whatsapp}`}
                target="_blank"
                rel="noreferrer"
                className="inline-flex items-center justify-center gap-2 rounded-full border border-ivory-100/30 px-7 py-3 text-sm font-medium uppercase tracking-[0.15em] text-ivory-50 transition-all hover:bg-ivory-50 hover:text-charcoal-900"
              >
                <MessageCircle size={15} /> WhatsApp
              </a>
            </div>
          </div>
        </Reveal>
      </div>
    </div>
  );
}
