import { Link } from 'react-router-dom';
import { ArrowRight } from 'lucide-react';
import Reveal from '../components/Reveal';
import { useCategories } from '../lib/useCategories';

const collectionImages: Record<string, string> = {
  sarees: 'https://images.pexels.com/photos/8489763/pexels-photo-8489763.jpeg?auto=compress&cs=tinysrgb&w=800',
  'dress-materials': 'https://images.pexels.com/photos/8886949/pexels-photo-8886949.jpeg?auto=compress&cs=tinysrgb&w=800',
  'new-arrivals': 'https://images.pexels.com/photos/36430688/pexels-photo-36430688.jpeg?auto=compress&cs=tinysrgb&w=800',
};

export default function Collections() {
  const { mainCategories, loading } = useCategories();

  return (
    <div className="pt-28">
      <div className="container-luxe py-12 text-center">
        <Reveal>
          <p className="section-eyebrow">Browse</p>
          <h1 className="mt-3 text-5xl font-medium text-charcoal-900 md:text-6xl">Collections</h1>
          <p className="mx-auto mt-4 max-w-lg text-charcoal-800/70">
            Explore our curated collections — each a celebration of craftsmanship and timeless elegance.
          </p>
        </Reveal>
      </div>

      <div className="container-luxe pb-24">
        {loading ? (
          <div className="grid gap-6 sm:grid-cols-2 lg:grid-cols-3">
            {[...Array(5)].map((_, i) => (
              <div key={i} className="skeleton h-80 rounded-2xl" />
            ))}
          </div>
        ) : (
          <div className="grid gap-6 sm:grid-cols-2 lg:grid-cols-3">
            {mainCategories.map((cat, i) => (
              <Reveal key={cat.id} delay={i * 100}>
                <Link
                  to={`/collections/${cat.slug}`}
                  className="group relative block h-96 overflow-hidden rounded-2xl shadow-soft hover:shadow-luxe"
                >
                  <img
                    src={cat.image ?? collectionImages[cat.slug] ?? 'https://images.pexels.com/photos/8886949/pexels-photo-8886949.jpeg?auto=compress&cs=tinysrgb&w=800'}
                    alt={cat.name}
                    className="h-full w-full object-cover image-zoom"
                  />
                  <div className="absolute inset-0 bg-gradient-to-t from-charcoal-900/70 via-charcoal-900/20 to-transparent" />
                  <div className="absolute inset-x-0 bottom-0 p-7">
                    <h2 className="font-serif text-3xl font-medium text-ivory-50">{cat.name}</h2>
                    <p className="mt-2 text-sm text-ivory-100/80">{cat.description}</p>
                    <span className="mt-4 inline-flex items-center gap-1.5 text-xs font-medium uppercase tracking-[0.15em] text-champagne-200 transition-colors group-hover:text-champagne-100">
                      View Collection <ArrowRight size={14} />
                    </span>
                  </div>
                </Link>
              </Reveal>
            ))}
          </div>
        )}
      </div>
    </div>
  );
}
