import { Link, useParams } from 'react-router-dom';
import { ChevronRight } from 'lucide-react';
import Reveal from '../components/Reveal';
import ProductCard from '../components/ProductCard';
import { useCategories } from '../lib/useCategories';
import { useProducts } from '../lib/useProducts';

export default function SubcategoryListing() {
  const { slug, subslug } = useParams<{ slug: string; subslug: string }>();
  const { mainCategories, subcategories, loading: catLoading } = useCategories();
  const { products, loading: prodLoading } = useProducts({
    mainCategorySlug: slug,
    subcategorySlug: subslug,
  });

  const mainCategory = mainCategories.find((c) => c.slug === slug);
  const subcategory = subcategories.find(
    (s) => s.slug === subslug && s.main_category_id === mainCategory?.id,
  );

  if (catLoading) {
    return (
      <div className="pt-28">
        <div className="container-luxe py-12">
          <div className="skeleton mb-6 h-16 w-64 rounded-xl" />
          <div className="grid gap-6 sm:grid-cols-2 lg:grid-cols-4">
            {[...Array(4)].map((_, i) => (
              <div key={i} className="skeleton h-96 rounded-2xl" />
            ))}
          </div>
        </div>
      </div>
    );
  }

  if (!subcategory) {
    return (
      <div className="pt-28">
        <div className="container-luxe py-24 text-center">
          <h1 className="text-4xl font-medium text-charcoal-900">Category Not Found</h1>
          <Link to="/collections" className="btn-outline mt-6">
            Back to Collections
          </Link>
        </div>
      </div>
    );
  }

  return (
    <div className="pt-28">
      <div className="container-luxe py-4">
        <nav className="flex flex-wrap items-center gap-1.5 text-xs uppercase tracking-[0.12em] text-beige-500">
          <Link to="/" className="hover:text-champagne-500">Home</Link>
          <ChevronRight size={12} />
          <Link to="/collections" className="hover:text-champagne-500">Collections</Link>
          <ChevronRight size={12} />
          <Link to={`/collections/${slug}`} className="hover:text-champagne-500">
            {mainCategory?.name}
          </Link>
          <ChevronRight size={12} />
          <span className="text-charcoal-900">{subcategory.name}</span>
        </nav>
      </div>

      <div className="container-luxe py-8 text-center">
        <Reveal>
          <h1 className="text-4xl font-medium text-charcoal-900 md:text-5xl">{subcategory.name}</h1>
          {subcategory.description && (
            <p className="mx-auto mt-3 max-w-lg text-charcoal-800/70">{subcategory.description}</p>
          )}
        </Reveal>
      </div>

      <div className="container-luxe pb-24">
        {prodLoading ? (
          <div className="grid gap-6 sm:grid-cols-2 lg:grid-cols-4">
            {[...Array(4)].map((_, i) => (
              <div key={i} className="skeleton h-96 rounded-2xl" />
            ))}
          </div>
        ) : products.length === 0 ? (
          <p className="py-16 text-center text-charcoal-800/60">
            New pieces are being curated. Visit our boutique or check back soon.
          </p>
        ) : (
          <div className="grid gap-6 sm:grid-cols-2 lg:grid-cols-4">
            {products.map((p, i) => (
              <Reveal key={p.id} delay={i * 80}>
                <ProductCard product={p} />
              </Reveal>
            ))}
          </div>
        )}
      </div>
    </div>
  );
}
