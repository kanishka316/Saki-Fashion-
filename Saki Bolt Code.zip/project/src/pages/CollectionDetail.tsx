import { Link, useParams } from 'react-router-dom';
import { ArrowRight, ChevronRight } from 'lucide-react';
import Reveal from '../components/Reveal';
import ProductCard from '../components/ProductCard';
import { useCategories } from '../lib/useCategories';
import { useProducts } from '../lib/useProducts';

// Real Pexels photos of Indian women's ethnic wear, mapped by subcategory slug
const subcategoryImages: Record<string, string> = {
  // Sarees
  'cotton-sarees': 'https://images.pexels.com/photos/7920055/pexels-photo-7920055.jpeg?auto=compress&cs=tinysrgb&w=600',
  'silk-sarees': 'https://images.pexels.com/photos/29105327/pexels-photo-29105327.jpeg?auto=compress&cs=tinysrgb&w=600',
  'kanchipuram-sarees': 'https://images.pexels.com/photos/29049358/pexels-photo-29049358.jpeg?auto=compress&cs=tinysrgb&w=600',
  'banarasi-sarees': 'https://images.pexels.com/photos/28517491/pexels-photo-28517491.jpeg?auto=compress&cs=tinysrgb&w=600',
  'soft-silk-sarees': 'https://images.pexels.com/photos/30193764/pexels-photo-30193764.jpeg?auto=compress&cs=tinysrgb&w=600',
  'fancy-sarees': 'https://images.pexels.com/photos/32346245/pexels-photo-32346245.jpeg?auto=compress&cs=tinysrgb&w=600',
  'designer-sarees': 'https://images.pexels.com/photos/29819599/pexels-photo-29819599.jpeg?auto=compress&cs=tinysrgb&w=600',
  'wedding-sarees': 'https://images.pexels.com/photos/32161001/pexels-photo-32161001.jpeg?auto=compress&cs=tinysrgb&w=600',
  'bridal-sarees': 'https://images.pexels.com/photos/18010643/pexels-photo-18010643.jpeg?auto=compress&cs=tinysrgb&w=600',
  'party-wear-sarees': 'https://images.pexels.com/photos/18346884/pexels-photo-18346884.jpeg?auto=compress&cs=tinysrgb&w=600',
  'printed-sarees': 'https://images.pexels.com/photos/7176428/pexels-photo-7176428.jpeg?auto=compress&cs=tinysrgb&w=600',
  'daily-wear-sarees': 'https://images.pexels.com/photos/11627915/pexels-photo-11627915.jpeg?auto=compress&cs=tinysrgb&w=600',
  'linen-sarees': 'https://images.pexels.com/photos/8750027/pexels-photo-8750027.jpeg?auto=compress&cs=tinysrgb&w=600',
  // Dress Materials
  'cotton-materials': 'https://images.pexels.com/photos/8886949/pexels-photo-8886949.jpeg?auto=compress&cs=tinysrgb&w=600',
  'silk-materials': 'https://images.pexels.com/photos/8886952/pexels-photo-8886952.jpeg?auto=compress&cs=tinysrgb&w=600',
  'printed-materials': 'https://images.pexels.com/photos/8887121/pexels-photo-8887121.jpeg?auto=compress&cs=tinysrgb&w=600',
  'designer-materials': 'https://images.pexels.com/photos/8886939/pexels-photo-8886939.jpeg?auto=compress&cs=tinysrgb&w=600',
  'fancy-materials': 'https://images.pexels.com/photos/8750027/pexels-photo-8750027.jpeg?auto=compress&cs=tinysrgb&w=600',
  'linen-materials': 'https://images.pexels.com/photos/8886949/pexels-photo-8886949.jpeg?auto=compress&cs=tinysrgb&w=600',
  'daily-wear-materials': 'https://images.pexels.com/photos/5094488/pexels-photo-5094488.jpeg?auto=compress&cs=tinysrgb&w=600',
};

const fallbackImg = 'https://images.pexels.com/photos/8886949/pexels-photo-8886949.jpeg?auto=compress&cs=tinysrgb&w=600';

export default function CollectionDetail() {
  const { slug } = useParams<{ slug: string }>();
  const { mainCategories, subcategories, loading: catLoading } = useCategories();
  const isNewArrivals = slug === 'new-arrivals';
  const { products, loading: prodLoading } = useProducts(
    isNewArrivals ? { newArrivalsOnly: true } : { mainCategorySlug: slug },
  );

  const mainCategory = mainCategories.find((c) => c.slug === slug);
  const subs = subcategories.filter((s) => s.main_category_id === mainCategory?.id);

  if (catLoading) {
    return (
      <div className="pt-28">
        <div className="container-luxe py-12">
          <div className="skeleton mb-6 h-16 w-64 rounded-xl" />
          <div className="grid gap-6 sm:grid-cols-2 lg:grid-cols-3">
            {[...Array(6)].map((_, i) => (
              <div key={i} className="skeleton h-80 rounded-2xl" />
            ))}
          </div>
        </div>
      </div>
    );
  }

  if (!mainCategory && !isNewArrivals) {
    return (
      <div className="pt-28">
        <div className="container-luxe py-24 text-center">
          <h1 className="text-4xl font-medium text-charcoal-900">Collection Not Found</h1>
          <Link to="/collections" className="btn-outline mt-6">
            Back to Collections
          </Link>
        </div>
      </div>
    );
  }

  const title = isNewArrivals ? 'New Arrivals' : mainCategory!.name;
  const description = isNewArrivals
    ? 'The latest additions to our boutique.'
    : mainCategory!.description;

  return (
    <div className="pt-28">
      {/* Breadcrumb */}
      <div className="container-luxe py-4">
        <nav className="flex items-center gap-1.5 text-xs uppercase tracking-[0.12em] text-beige-500">
          <Link to="/" className="hover:text-champagne-500">Home</Link>
          <ChevronRight size={12} />
          <Link to="/collections" className="hover:text-champagne-500">Collections</Link>
          <ChevronRight size={12} />
          <span className="text-charcoal-900">{title}</span>
        </nav>
      </div>

      {/* Header */}
      <div className="container-luxe py-8 text-center">
        <Reveal>
          <h1 className="text-5xl font-medium text-charcoal-900 md:text-6xl">{title}</h1>
          <p className="mx-auto mt-4 max-w-lg text-charcoal-800/70">{description}</p>
        </Reveal>
      </div>

      {/* New Arrivals: show products directly */}
      {isNewArrivals ? (
        <div className="container-luxe pb-24">
          {prodLoading ? (
            <div className="grid gap-6 sm:grid-cols-2 lg:grid-cols-4">
              {[...Array(4)].map((_, i) => (
                <div key={i} className="skeleton h-96 rounded-2xl" />
              ))}
            </div>
          ) : products.length === 0 ? (
            <p className="py-12 text-center text-charcoal-800/60">No new arrivals yet. Check back soon.</p>
          ) : (
            <div className="grid gap-6 sm:grid-cols-2 lg:grid-cols-4">
              {products.map((p, i) => (
                <Reveal key={p.id} delay={i * 80}>
                  <ProductCard product={p} />
                </Reveal>
              ))}
            </div>
          )}
        </div>
      ) : (
        <>
          {/* Subcategories grid */}
          {subs.length > 0 && (
            <div className="container-luxe pb-12">
              <Reveal>
                <h2 className="mb-8 text-center text-2xl font-medium text-charcoal-900">
                  Sub-Categories
                </h2>
              </Reveal>
              <div className="grid gap-6 sm:grid-cols-2 lg:grid-cols-3">
                {subs.map((sub, i) => (
                  <Reveal key={sub.id} delay={i * 80}>
                    <Link
                      to={`/collections/${slug}/${sub.slug}`}
                      className="group relative block h-72 overflow-hidden rounded-2xl shadow-soft hover:shadow-luxe"
                    >
                      <img
                        src={sub.image ?? subcategoryImages[sub.slug] ?? fallbackImg}
                        alt={sub.name}
                        className="h-full w-full object-cover image-zoom"
                      />
                      <div className="absolute inset-0 bg-gradient-to-t from-charcoal-900/65 via-charcoal-900/15 to-transparent" />
                      <div className="absolute inset-x-0 bottom-0 p-6">
                        <h3 className="font-serif text-xl font-medium text-ivory-50">{sub.name}</h3>
                        {sub.description && (
                          <p className="mt-1 text-xs text-ivory-100/70">{sub.description}</p>
                        )}
                        <span className="mt-3 inline-flex items-center gap-1.5 text-xs font-medium uppercase tracking-[0.15em] text-champagne-200 transition-colors group-hover:text-champagne-100">
                          View Collection <ArrowRight size={14} />
                        </span>
                      </div>
                    </Link>
                  </Reveal>
                ))}
              </div>
            </div>
          )}

          {/* Also show products in this main category */}
          <div className="container-luxe pb-24">
            <Reveal>
              <h2 className="mb-8 text-2xl font-medium text-charcoal-900">All {title}</h2>
            </Reveal>
            {prodLoading ? (
              <div className="grid gap-6 sm:grid-cols-2 lg:grid-cols-4">
                {[...Array(4)].map((_, i) => (
                  <div key={i} className="skeleton h-96 rounded-2xl" />
                ))}
              </div>
            ) : products.length === 0 ? (
              <p className="py-12 text-center text-charcoal-800/60">
                Products coming soon. Visit our boutique or check back later.
              </p>
            ) : (
              <div className="grid gap-6 sm:grid-cols-2 lg:grid-cols-4">
                {products.map((p, i) => (
                  <Reveal key={p.id} delay={i * 80}>
                    <ProductCard product={p} />
                  </Reveal>
                ))}
              </div>
            )}
          </div>
        </>
      )}
    </div>
  );
}
