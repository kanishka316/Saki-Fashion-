import { useState, useEffect } from 'react';
import { Link, useParams } from 'react-router-dom';
import { ChevronRight, ChevronLeft, X, Check, Phone, MessageCircle, Instagram } from 'lucide-react';
import { useProduct } from '../lib/useProducts';
import { useCategories } from '../lib/useCategories';
import { CONTACT } from '../lib/constants';

const availabilityStyles: Record<string, { badge: string; dot: string }> = {
  'In Stock': { badge: 'bg-green-100 text-green-700', dot: 'bg-green-500' },
  'Limited Stock': { badge: 'bg-champagne-200 text-champagne-700', dot: 'bg-champagne-500' },
  'Out of Stock': { badge: 'bg-red-100 text-red-600', dot: 'bg-red-500' },
};

export default function ProductDetails() {
  const { id } = useParams<{ id: string }>();
  const { product, loading } = useProduct(id);
  const { mainCategories, subcategories } = useCategories();
  const [activeImg, setActiveImg] = useState(0);
  const [zoomOpen, setZoomOpen] = useState(false);
  const [touchStart, setTouchStart] = useState(0);

  useEffect(() => {
    setActiveImg(0);
  }, [id]);

  const mainCategory = product
    ? mainCategories.find((c) => c.id === product.main_category_id)
    : null;
  const subcategory = product?.subcategory_id
    ? subcategories.find((s) => s.id === product.subcategory_id)
    : null;

  if (loading) {
    return (
      <div className="pt-28">
        <div className="container-luxe py-12">
          <div className="grid gap-12 md:grid-cols-2">
            <div className="skeleton aspect-[3/4] rounded-2xl" />
            <div className="space-y-4">
              <div className="skeleton h-10 w-3/4 rounded-xl" />
              <div className="skeleton h-6 w-1/3 rounded-lg" />
              <div className="skeleton h-32 w-full rounded-xl" />
            </div>
          </div>
        </div>
      </div>
    );
  }

  if (!product) {
    return (
      <div className="pt-28">
        <div className="container-luxe py-24 text-center">
          <h1 className="text-4xl font-medium text-charcoal-900">Product Not Found</h1>
          <Link to="/collections" className="btn-outline mt-6">
            Back to Collections
          </Link>
        </div>
      </div>
    );
  }

  const images = product.images.length > 0 ? product.images : [];
  const avail = availabilityStyles[product.availability] ?? availabilityStyles['In Stock'];

  const handleTouchEnd = (e: React.TouchEvent) => {
    const diff = e.changedTouches[0].clientX - touchStart;
    if (diff > 50 && activeImg > 0) setActiveImg(activeImg - 1);
    else if (diff < -50 && activeImg < images.length - 1) setActiveImg(activeImg + 1);
  };

  return (
    <div className="pt-28">
      <div className="container-luxe py-4">
        <nav className="flex flex-wrap items-center gap-1.5 text-xs uppercase tracking-[0.12em] text-beige-500">
          <Link to="/" className="hover:text-champagne-500">Home</Link>
          <ChevronRight size={12} />
          <Link to="/collections" className="hover:text-champagne-500">Collections</Link>
          {mainCategory && (
            <>
              <ChevronRight size={12} />
              <Link to={`/collections/${mainCategory.slug}`} className="hover:text-champagne-500">
                {mainCategory.name}
              </Link>
            </>
          )}
          {subcategory && (
            <>
              <ChevronRight size={12} />
              <Link
                to={`/collections/${mainCategory?.slug}/${subcategory.slug}`}
                className="hover:text-champagne-500"
              >
                {subcategory.name}
              </Link>
            </>
          )}
          <ChevronRight size={12} />
          <span className="text-charcoal-900">{product.product_code}</span>
        </nav>
      </div>

      <div className="container-luxe py-8">
        <div className="grid gap-12 lg:grid-cols-2">
          {/* Gallery */}
          <div>
            <div
              className="relative aspect-[3/4] overflow-hidden rounded-2xl bg-ivory-100 shadow-soft"
              onTouchStart={(e) => setTouchStart(e.touches[0].clientX)}
              onTouchEnd={handleTouchEnd}
            >
              {images.length > 0 ? (
                <img
                  src={images[activeImg]}
                  alt={product.name}
                  className="h-full w-full cursor-zoom-in object-cover transition-opacity duration-300"
                  onClick={() => setZoomOpen(true)}
                />
              ) : (
                <div className="flex h-full w-full items-center justify-center text-beige-400">
                  No Image Available
                </div>
              )}
              {images.length > 1 && (
                <>
                  <button
                    onClick={() => setActiveImg((i) => (i - 1 + images.length) % images.length)}
                    className="absolute left-3 top-1/2 -translate-y-1/2 rounded-full bg-ivory-50/80 p-2 text-charcoal-900 transition-colors hover:bg-champagne-400"
                    aria-label="Previous image"
                  >
                    <ChevronLeft size={20} />
                  </button>
                  <button
                    onClick={() => setActiveImg((i) => (i + 1) % images.length)}
                    className="absolute right-3 top-1/2 -translate-y-1/2 rounded-full bg-ivory-50/80 p-2 text-charcoal-900 transition-colors hover:bg-champagne-400"
                    aria-label="Next image"
                  >
                    <ChevronRight size={20} />
                  </button>
                </>
              )}
            </div>

            {/* Thumbnails */}
            {images.length > 1 && (
              <div className="mt-4 flex gap-3 overflow-x-auto pb-2">
                {images.map((img, i) => (
                  <button
                    key={i}
                    onClick={() => setActiveImg(i)}
                    className={`relative h-20 w-16 shrink-0 overflow-hidden rounded-lg border-2 transition-all ${
                      i === activeImg ? 'border-champagne-400' : 'border-transparent opacity-70'
                    }`}
                  >
                    <img src={img} alt={`${product.name} ${i + 1}`} className="h-full w-full object-cover" />
                  </button>
                ))}
              </div>
            )}
          </div>

          {/* Info */}
          <div className="lg:pt-4">
            {product.is_new_arrival && (
              <span className="inline-block rounded-full bg-charcoal-900 px-3 py-1 text-[0.6rem] font-medium uppercase tracking-[0.15em] text-ivory-50">
                New Arrival
              </span>
            )}
            <h1 className="mt-3 text-4xl font-medium text-charcoal-900 md:text-5xl">{product.name}</h1>
            <p className="mt-2 text-sm uppercase tracking-[0.15em] text-beige-500">
              {product.product_code}
            </p>

            <div className="mt-4">
              <span
                className={`inline-flex items-center gap-2 rounded-full px-3 py-1.5 text-xs font-medium ${avail.badge}`}
              >
                <span className={`h-2 w-2 rounded-full ${avail.dot}`} />
                {product.availability}
              </span>
            </div>

            {product.fabric && (
              <div className="mt-6">
                <h3 className="label-luxe">Fabric</h3>
                <p className="text-base text-charcoal-800/80">{product.fabric}</p>
              </div>
            )}

            {product.description && (
              <div className="mt-6">
                <h3 className="label-luxe">Description</h3>
                <p className="text-base leading-relaxed text-charcoal-800/80">{product.description}</p>
              </div>
            )}

            {product.colours.length > 0 && (
              <div className="mt-6">
                <h3 className="label-luxe">Available Colours</h3>
                <div className="flex flex-wrap gap-2">
                  {product.colours.map((c) => (
                    <span
                      key={c}
                      className="inline-flex items-center gap-1.5 rounded-full border border-ivory-300 bg-ivory-50 px-3 py-1.5 text-sm text-charcoal-800"
                    >
                      <Check size={13} className="text-champagne-500" />
                      {c}
                    </span>
                  ))}
                </div>
              </div>
            )}

            {/* Enquire section */}
            <div className="mt-10 rounded-2xl bg-ivory-100 p-6">
              <h3 className="font-serif text-xl font-medium text-charcoal-900">
                Interested in this piece?
              </h3>
              <p className="mt-1.5 text-sm text-charcoal-800/70">
                Visit our boutique or reach out to us directly for more details.
              </p>
              <div className="mt-4 flex flex-wrap gap-3">
                <a href={`tel:${CONTACT.phoneRaw}`} className="btn-primary">
                  <Phone size={15} /> Call
                </a>
                <a
                  href={`https://wa.me/${CONTACT.whatsapp}?text=${encodeURIComponent(
                    `Hello Saki, I'm interested in ${product.name} (${product.product_code}).`,
                  )}`}
                  target="_blank"
                  rel="noreferrer"
                  className="btn-outline"
                >
                  <MessageCircle size={15} /> WhatsApp
                </a>
                <a
                  href={CONTACT.instagram}
                  target="_blank"
                  rel="noreferrer"
                  className="btn-ghost"
                >
                  <Instagram size={15} /> Instagram
                </a>
              </div>
            </div>
          </div>
        </div>
      </div>

      {/* Zoom modal */}
      {zoomOpen && images.length > 0 && (
        <div
          className="fixed inset-0 z-[100] flex items-center justify-center bg-charcoal-900/90 p-4 animate-fadeIn"
          onClick={() => setZoomOpen(false)}
        >
          <button
            className="absolute right-6 top-6 rounded-full bg-ivory-50/20 p-2 text-ivory-50 transition-colors hover:bg-champagne-400"
            onClick={() => setZoomOpen(false)}
          >
            <X size={24} />
          </button>
          <img
            src={images[activeImg]}
            alt={product.name}
            className="max-h-[90vh] max-w-full rounded-xl object-contain"
            onClick={(e) => e.stopPropagation()}
          />
        </div>
      )}
    </div>
  );
}
